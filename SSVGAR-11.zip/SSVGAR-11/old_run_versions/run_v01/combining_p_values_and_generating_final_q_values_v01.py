import numpy as np
import pandas as pd
from check_copy_number_for_certain_regions import find_average_copy_number_for_patients_that_have_and_dont_have_SVs_for_this_gene
from SV_analysis_superenhancer_regions import produce_df_for_analyzing_breakpoints_near_enhancers
from SV_analysis_loss_of_function_events_v01 import produce_analysis_df
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test import produce_p_values_for_genes_enriched_and_depleted
import scipy.stats
from statsmodels.stats import multitest

# This is the SV list with the 30 SVs corresponding to 16 low-purity samples removed:
SV_df = pd.read_csv('All_Pairs.dRanger_etc.filtered_SV.columns_subset_enhanced_genes_100000bp_with_annotations.tsv', sep='\t')

superenhancer_analysis_df = produce_df_for_analyzing_breakpoints_near_enhancers()
LOF_analysis_df = produce_analysis_df()
enriched_rna_df, depleted_rna_df = produce_p_values_for_genes_enriched_and_depleted()

merged_df_with_p_values = LOF_analysis_df[['Gene', 
                                          'Number of Patients with SV breakpoint annotated with gene',
                                          'Number of SVs', 
                                          'Number of SV breakpoints',
                                          'Number of breakpoints with LOF by my criteria',
                                          'Prop. of breakpoints with LOF by my criteria',
                                          'p-value of given number of breakpoints or more having LOF']].merge(depleted_rna_df[['genes','p-values']],left_on='Gene',right_on='genes').drop(columns='genes').rename(columns={"p-values": "p-values for RNA underexpression"})

merged_df_with_p_values_and_q_values = merged_df_with_p_values[merged_df_with_p_values['Number of Patients with SV breakpoint annotated with gene'] >= 5].copy()
merged_df_with_p_values_and_q_values['Combined p-values'] = list(map(lambda x: scipy.stats.combine_pvalues([x[0],x[1]],method='fisher')[1], zip(list(merged_df_with_p_values_and_q_values['p-value of given number of breakpoints or more having LOF']), list(merged_df_with_p_values_and_q_values['p-values for RNA underexpression']))))
merged_df_with_p_values_and_q_values['Final q-values'] = multitest.multipletests(list(merged_df_with_p_values_and_q_values['Combined p-values']), method = "fdr_bh")[1]
merged_df_with_p_values_and_q_values.sort_values(['Final q-values','Combined p-values'], ascending=[True,True], inplace=True)

# merged_df_with_p_values_and_q_values = merged_df_with_p_values.apply(lambda x: scipy.stats.combine_pvalues([x['p-value of given number of breakpoints or more having LOF'],x['p-values for RNA underexpression']],method='fisher'))


