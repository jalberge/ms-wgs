import numpy as np
import pandas as pd
from liftover import get_lifter



converter = get_lifter('hg19', 'hg38')
sex_chromosome_mapper = {23:'X',24:'Y'}

type_of_subset = 'lymphoid'
# type_of_subset = 'lymphoma'

PCAWG_list_subset_df = pd.read_csv('merged_1.6.1.PCAWG_SV_list.subset_' + type_of_subset + '.csv')
PCAWG_list_subset_df['start'] = list(map(lambda x: converter[sex_chromosome_mapper[x[0]]][x[1]][0][1] if (x[0] == 23 or x[0] == 24) else converter[str(x[0])][x[1]][0][1], zip(list(PCAWG_list_subset_df['seqnames']),list(PCAWG_list_subset_df['start']))))
PCAWG_list_subset_df['altpos'] = list(map(lambda x: converter[sex_chromosome_mapper[x[0]]][x[1]][0][1] if (x[0] == 23 or x[0] == 24) else converter[str(x[0])][x[1]][0][1], zip(list(PCAWG_list_subset_df['altchr']),list(PCAWG_list_subset_df['altpos']))))

PCAWG_list_subset_df = PCAWG_list_subset_df.to_csv('merged_1.6.1.PCAWG_SV_list.subset_' + type_of_subset + '.lifted_over.csv',index=False)


