import pandas as pd
import numpy as np
import random
from statsmodels.stats import multitest
# from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test_v09 import produce_p_values_for_genes_enriched_and_depleted
from SV_analysis_loss_of_function_events_v09 import load_and_prepare_R_mat_file_into_df
from SV_analysis_loss_of_function_events_v09 import convert_chr_xavi


def anonymize_genes(gene_list):
    the_gene_list = sorted(gene_list)
    random.seed(100) # Chose random seed number arbitrarily/randomly; it doesn't matter what it is as long as it remains the same for our analysis
    random.shuffle(the_gene_list)
    anonymized_ids = list(map(lambda x: 'anonymized_gene_' + str(x), list(range(0,len(the_gene_list)))))
    genes_to_anonymized_ids = {}
    for i in range(len(the_gene_list)):
        genes_to_anonymized_ids[the_gene_list[i]] = anonymized_ids[i]
    return genes_to_anonymized_ids


if __name__ == '__main__':
    
    # Can copy and paste what's below into ipython and see the results you want to see:

    R_mat_file_path='../reference_files/annotation_file/hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat'
    R_mat_loaded_and_prepared_df = load_and_prepare_R_mat_file_into_df(R_mat_file_path)

    genes_to_cytobands_df = pd.read_csv("../reference_files/genes_to_cytobands/genes_to_cytobands.tsv",sep='\t')
    genes_to_cytobands_dict = {}
    for i,r in genes_to_cytobands_df.iterrows():
        genes_to_cytobands_dict[r['gene']] = r['cytoband']
        
    list_of_genes_from_CGC_with_connection_to_NHL_or_DLBCL = []
    f = open('../reference_files/specific_lists_of_known_driver_genes/genes_from_CGC_with_connection_to_NHL_or_DLBCL.txt',mode='r')
    for line in f.readlines():
        if not line.startswith('#'):
            list_of_genes_from_CGC_with_connection_to_NHL_or_DLBCL.append(line.strip())
    list_of_genes_bated_for_SVs_in_chapuy_et_al = []
    f = open('../reference_files/specific_lists_of_known_driver_genes/genes_bated_for_SVs_in_dlbcl_chapuy_et_al_2018.txt',mode='r')
    for line in f.readlines():
        if not line.startswith('#'):
            list_of_genes_bated_for_SVs_in_chapuy_et_al.append(line.strip())
    list_of_TS_genes_figure1a_staudt_2018_paper = []
    f = open('../reference_files/specific_lists_of_known_driver_genes/genes_from_figure1a_of_dlbcl_schmitz_et_al_2018_paper_under_lou_staudt.txt',mode='r')
    for line in f.readlines():
        if not line.startswith('#'):
            list_of_TS_genes_figure1a_staudt_2018_paper.append(line.strip())

    gene_list = sorted(list(set(R_mat_loaded_and_prepared_df['gene'])))
    genes_to_anonymized_ids = anonymize_genes(gene_list)
    
    ####################### PARAMETERS TO SPECIFY #######################
    # Need to set which_dataset when running:
    which_dataset = "CTSP_DLBCL" # possible datasets right now: CTSP_DLBCL, PCAWG_lymphoid, PCAWG_lymphoma
    # Need to set d (surrounding window threshold):
    d = 1000000
    # Need to specify the minimum number of patients with SV breakpoints found within the specified window of each gene to use the gene for multiple test correction:
    min_num_patients = 6
    # Boolean for whether or not we want to anonymize genes:
    anonymize_genes_bool = True
    # Need to specify path of the relevant results for running SVGAR_sf:
    LOF_v09_analysis_df = pd.read_csv("../model_results/" + which_dataset + "/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_" + str(d) + "bp_v09.tsv", sep='\t')
    ################### END OF PARAMETERS TO SPECIFY ####################
    
    # if which_dataset == "CTSP_DLBCL" or which_dataset == "PCAWG_lymphoma": # These are the two datasets for which we have RNA-seq Wilcoxon ranksum test results
    #     the_enriched_rna_df = pd.read_csv("rna_wilcoxon_tsvs/" + which_dataset + "/enriched_rna_wilcoxon_tsv_v09.tsv",sep='\t')
    #     the_depleted_rna_df = pd.read_csv("rna_wilcoxon_tsvs/" + which_dataset + "/depleted_rna_wilcoxon_tsv_v09.tsv",sep='\t')
    
    filtered_LOF_v09_analysis_df = LOF_v09_analysis_df[LOF_v09_analysis_df['num_total_events_used_for_test'] > 0]
    
    # if which_dataset == "CTSP_DLBCL" or which_dataset == "PCAWG_lymphoma":
    #     filtered_LOF_v09_analysis_df['RNA_underexp_p_value'] = list(map(lambda x: the_depleted_rna_df[the_depleted_rna_df['genes'] == x]['p-values'].iloc[0] if the_depleted_rna_df[the_depleted_rna_df['genes'] == x].shape[0] > 0 else "N/A", list(filtered_LOF_v09_analysis_df['gene'])))
    filtered_LOF_v09_analysis_df['gene_cytoband'] = list(map(lambda g: genes_to_cytobands_dict[g], list(filtered_LOF_v09_analysis_df['gene'])))
    filtered_LOF_v09_analysis_df['anonymized_gene'] = list(map(lambda g: genes_to_anonymized_ids[g], list(filtered_LOF_v09_analysis_df['gene'])))
    filtered_LOF_v09_analysis_df['is_DLBCL_or_NHL_TSG_or_fusion_gene_in_CGC'] = list(map(lambda g: "yes" if g in list_of_genes_from_CGC_with_connection_to_NHL_or_DLBCL else "no", list(filtered_LOF_v09_analysis_df['gene'])))
    filtered_LOF_v09_analysis_df['is_bated_SV_gene_in_chapuy_et_al'] = list(map(lambda g: "yes" if g in list_of_genes_bated_for_SVs_in_chapuy_et_al else "no", list(filtered_LOF_v09_analysis_df['gene'])))
    filtered_LOF_v09_analysis_df['is_TSG_in_figure1a_staudt_2018'] = list(map(lambda g: "yes" if g in list_of_TS_genes_figure1a_staudt_2018_paper else "no", list(filtered_LOF_v09_analysis_df['gene'])))
    filtered_LOF_v09_analysis_df = filtered_LOF_v09_analysis_df[filtered_LOF_v09_analysis_df['num_patients_used_for_test'] >= min_num_patients].copy()
    filtered_LOF_v09_analysis_df['q_value_LOF'] = multitest.multipletests(list(filtered_LOF_v09_analysis_df['p_value_LOF']), method = "fdr_bh")[1]
    if anonymize_genes_bool:
        gene_column_name = 'anonymized_gene'
    else:
        gene_column_name = 'gene'
    # if which_dataset == "CTSP_DLBCL" or which_dataset == "PCAWG_lymphoma":
    #     filtered_LOF_v09_analysis_df = filtered_LOF_v09_analysis_df[[gene_column_name,'is_DLBCL_or_NHL_TSG_or_fusion_gene_in_CGC','is_bated_SV_gene_in_chapuy_et_al','is_TSG_in_figure1a_staudt_2018','num_patients_used_for_test','num_patients_with_at_least_one_LOF_event',
    #                                                                 'num_total_events_used_for_test','num_intragenic_events','num_intergenic_events','num_LOF_events','prob_of_LOF','p_value_LOF','q_value_LOF','RNA_underexp_p_value','gene_cytoband']]
    # else:
    filtered_LOF_v09_analysis_df = filtered_LOF_v09_analysis_df[[gene_column_name,'is_DLBCL_or_NHL_TSG_or_fusion_gene_in_CGC','is_bated_SV_gene_in_chapuy_et_al','is_TSG_in_figure1a_staudt_2018','num_patients_used_for_test','num_patients_with_at_least_one_LOF_event',
                                                                'num_total_events_used_for_test','num_intragenic_events','num_intergenic_events','num_LOF_events','prob_of_LOF','p_value_LOF','q_value_LOF','gene_cytoband']]
    
    # The below is to view the significant/near-significant genes sorted by p-value from the above code (can also just view in iPython, may be more convenient):
    print('\n')
    print(filtered_LOF_v09_analysis_df[filtered_LOF_v09_analysis_df['q_value_LOF'] <= 0.25].sort_values(by=['p_value_LOF']))

    return filtered_LOF_v09_analysis_df[filtered_LOF_v09_analysis_df['q_value_LOF'] <= 0.25].sort_values(by=['p_value_LOF'])
    
