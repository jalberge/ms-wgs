import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from statsmodels.stats import multitest
from adjustText import adjust_text
import scipy.stats
from statsmodels.stats import multitest
from qtl import annotation
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test_v10 import produce_p_values_for_genes_enriched_and_depleted

# This is me modifying Julian's version of his QQ plots function for my analysis:
def custom_QQ(pvalues, pmidvalues = None, labels = None, sig_thresh = 0.1, near_sig_thresh = 0.25, fnum = None, neg_log10_cutoff = None): # neg_log10_cutoff is a new parameter I introduced
    si = np.argsort(-np.log10(pvalues))
    logp = -np.log10(pvalues)[si]
    
    if pmidvalues:
        si_pmid = np.argsort(-np.log10(pmidvalues))
        logp_pmid = -np.log10(pmidvalues)[si_pmid]
        assert len(logp) == len(logp_pmid)
    
    n_p = len(logp)

    # expected quantiles
    x = -np.log10(np.r_[n_p:0:-1]/(n_p + 1))

    # FDR
    _, q, _, _ = multitest.multipletests(pvalues[si], method = "fdr_bh")
    sig_idx = q < sig_thresh
    n_sig_idx = q < near_sig_thresh

    fdr_color_idx = np.c_[sig_idx, n_sig_idx]@np.r_[2, 1]

    #                      nonsig     near sig   <padding>     sig
    fdr_colors = np.array([[0, 0, 1], [0, 1, 1], [-1, -1, -1], [1, 0, 0]])

    #
    # plot
    f = plt.figure(fnum); plt.clf()
    if not pmidvalues:
        plt.scatter(x, logp, c = fdr_colors[fdr_color_idx])
    else:
        plt.scatter(x, logp_pmid, c = fdr_colors[fdr_color_idx])

    # 1:1 line
    plt.plot(plt.xlim(), plt.xlim(), color = 'k', linestyle = ':')
    
    # Modification I made -Xavi:
    if neg_log10_cutoff:
        orig_bottom,orig_top = plt.ylim()
        plt.ylim(orig_bottom,neg_log10_cutoff)

    #
    # labels (if given)
    if labels is not None:
        if len(labels) != len(x):
            raise ValueError("Length of labels must match length of p-value array")
        labels = labels[si]
        label_plt = [plt.text(x, y, l) for x, y, l in zip(x[n_sig_idx], logp[n_sig_idx], labels[n_sig_idx])]
        adjust_text(label_plt, arrowprops = { 'color' : 'k', "arrowstyle" : "-" })

    plt.xlabel("Expected quantile (-log10)")
    plt.ylabel("Observed quantile (-log10)")

    return f

####################### PARAMETERS TO SPECIFY #######################
# Need to set which_dataset when running:
which_dataset = "CTSP_DLBCL" # possible datasets right now: CTSP_DLBCL, PCAWG_lymphoid, PCAWG_lymphoma, JB_MM_SU2C
# Need to specify whether we wish to use actual p-values for mid-p-values for QQ plot plotting:
use_p_mid = False # possible values: True (to use p-mid for plotting), False (to do regular QQ plots)
# Need to specify which surrounding window parameter we wish to use for our QQ plots:
surrounding_window_parameter = 1000000
# Need to specify the minimum number of patients with SV breakpoints found within the specified window of each gene to use the gene for multiple test correction:
min_num_patients_for_multiple_test_correction = 6
# Specify a negative-log10 cutoff (such as 1, 2, 3, 4, 2.5, 3.6, etc.) for viewing the QQ plot if you so desire, otherwise None is fine as a value:
QQ_lot_neg_log10_cutoff = None
# Need to specify path of the relevant results for running SVGAR_sf:
LOF_v10_analysis_df = pd.read_csv("../model_results/" + which_dataset + "/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_" + str(surrounding_window_parameter) + "bp_v10.tsv", sep='\t')
################### END OF PARAMETERS TO SPECIFY ####################


# for d in [0,50000,100000,200000,500000,1000000]:
# for d in [1000000]:
# for d in [0]:
# for d in [47825,95649,944000]:
# for d in range(0,5*10**6+1,100000):
for d in [surrounding_window_parameter]:
    # I think it is better to produce QQ plots without merging the RNA-seq underexpression dataframe. That way we are not leaving out certain genes we applied the LOF test to. 
    # for min_num_patients in [2,3,4,5,6,7,8]:
    # for min_num_patients in list(range(2,11)):
    for min_num_patients in list(range(min_num_patients_for_multiple_test_correction,min_num_patients_for_multiple_test_correction+1)):
        np.random.seed(min_num_patients * 10**8 + d)
        filtered_LOF_v10_analysis_df = LOF_v10_analysis_df[LOF_v10_analysis_df['num_total_events_used_for_test'] > 0].copy()
        filtered_LOF_v10_analysis_df = filtered_LOF_v10_analysis_df[filtered_LOF_v10_analysis_df['num_patients_used_for_test'] >= min_num_patients].copy()
        if not use_p_mid:
            fig_to_save = custom_QQ(np.array(list(filtered_LOF_v10_analysis_df['p_value_LOF'])),neg_log10_cutoff=QQ_lot_neg_log10_cutoff)
            additional_clause_indicating_p_mid = ""
        else:
            list_of_p_mids = []
            for i,row in filtered_LOF_v10_analysis_df.iterrows():
                x = row['num_LOF_events']
                n = row['num_total_events_used_for_test']
                p = row['prob_of_LOF']
                if x == n:
                    list_of_p_mids.append(row['p_value_LOF'] / 2)
                else:
                    pval = scipy.stats.binom_test(x, n=n, p=p, alternative='greater')
                    low_pval = scipy.stats.binom_test(x+1, n=n, p=p, alternative='greater')
                    list_of_p_mids.append(np.random.uniform(low_pval, pval))
            filtered_LOF_v10_analysis_df['p_value_mid_LOF'] = list_of_p_mids
            fig_to_save = custom_QQ(np.array(list(filtered_LOF_v10_analysis_df['p_value_mid_LOF'])),neg_log10_cutoff=QQ_lot_neg_log10_cutoff)
            additional_clause_indicating_p_mid = ".pmid"
        filtered_LOF_v10_analysis_df['q_value_LOF'] = multitest.multipletests(list(filtered_LOF_v10_analysis_df['p_value_LOF']), method = "fdr_bh")[1]
        print("#######################")
        print("d = " + str(d) + ", min_num_patients = " + str(min_num_patients))
        print(filtered_LOF_v10_analysis_df.sort_values(by=['q_value_LOF']).head(25))
        if QQ_lot_neg_log10_cutoff:
            fig_to_save.savefig('../visualizations_and_associated_data/QQ_plots/' + which_dataset + '_QQ_plot_LOF_v10_model_pvalues_just_LOF_no_combination_thresh_of_proximity_' + str(d) + 'bp_min_' + str(min_num_patients) + '_patients' + '.cutoff_observed_quantile_at_1e-' + str(QQ_lot_neg_log10_cutoff) + additional_clause_indicating_p_mid + '.png')
        else:
            fig_to_save.savefig('../visualizations_and_associated_data/QQ_plots/' + which_dataset + '_QQ_plot_LOF_v10_model_pvalues_just_LOF_no_combination_thresh_of_proximity_' + str(d) + 'bp_min_' + str(min_num_patients) + '_patients' + additional_clause_indicating_p_mid + '.png')
        
