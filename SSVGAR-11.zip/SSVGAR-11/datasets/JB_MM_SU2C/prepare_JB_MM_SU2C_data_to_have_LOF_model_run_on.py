import pandas as pd 
import numpy as np 
import sys 
sys.path.insert(0, '/home/xloinaz/python_projects/dRangerPlus')
from dRanger_annotate_sites_prioritize_known_drivers import annotate_sites 

#### THIS PORTION OF THE CODE IS FOR RUNNING THE DRANGER ANNOTATOR:
P_parameters_dictionary = {}
P_parameters_dictionary['build'] = '/home/xloinaz/python_projects/dRangerPlus/relevant_R_mat_file/hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat'
P_parameters_dictionary['impute_promoters'] = True
P_parameters_dictionary['imputed_promoter_size'] = 3000
JB_MM_SU2C_df = pd.read_csv('20230509_MMRF_SU2C_MARK_OW_SV_filtered_results_baseline_hg38_sd_gt_0.tsv',sep='\t')
JB_MM_SU2C_df_annotated = annotate_sites(JB_MM_SU2C_df, P_parameters_dictionary)

JB_MM_SU2C_df_annotated.to_csv('20230509_MMRF_SU2C_MARK_OW_SV_filtered_results_baseline_hg38_sd_gt_0.annotated.tsv',sep='\t',index=False)


