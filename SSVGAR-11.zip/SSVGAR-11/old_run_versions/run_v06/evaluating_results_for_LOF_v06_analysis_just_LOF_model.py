import pandas as pd
import numpy as np
import random
from statsmodels.stats import multitest
from qtl import annotation
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test import produce_p_values_for_genes_enriched_and_depleted
from SV_analysis_loss_of_function_events_v06 import load_and_prepare_R_mat_file_into_df
from SV_analysis_loss_of_function_events_v06 import convert_chr_xavi


R_mat_file_path='hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat'
R_mat_loaded_and_prepared_df = load_and_prepare_R_mat_file_into_df(R_mat_file_path)

genes_to_cytobands_df = pd.read_csv("genes_to_cytobands.tsv",sep='\t')
genes_to_cytobands_dict = {}
for i,r in genes_to_cytobands_df.iterrows():
    genes_to_cytobands_dict[r['gene']] = r['cytoband']

# # This was what I used to do:
# SV_df = pd.read_csv("All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv",sep='\t')
# annot_v36 = annotation.Annotation("gencode.v36.annotation.gtf")
# the_enriched_rna_df, the_depleted_rna_df = produce_p_values_for_genes_enriched_and_depleted(annot_v36, "All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv")

# This is what I do now after running produce_tsvs_for_enriched_and_depleted_rna_tests_v06.py:
the_enriched_rna_df = pd.read_csv("enriched_rna_wilcoxon_tsv_v06.tsv",sep='\t')
the_depleted_rna_df = pd.read_csv("depleted_rna_wilcoxon_tsv_v06.tsv",sep='\t')


# # Need to set d (surrounding window threshold):
# d = 1000000

# Boolean for whether or not we want to anonymize genes:
anonymize_genes = True

if not anonymize_genes:
    # Can copy and paste what's below into ipython and see the results you want to see:
    LOF_v06_analysis_df = pd.read_csv("LOF_model_results/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_" + str(d) + "bp_v06.tsv", sep='\t')

    filtered_LOF_v06_analysis_df = LOF_v06_analysis_df[LOF_v06_analysis_df['num_total_events_used_for_test'] > 0]
    filtered_LOF_v06_analysis_df['RNA_underexp_p_value'] = list(map(lambda x: the_depleted_rna_df[the_depleted_rna_df['genes'] == x]['p-values'].iloc[0] if the_depleted_rna_df[the_depleted_rna_df['genes'] == x].shape[0] > 0 else "N/A", list(filtered_LOF_v06_analysis_df['gene'])))
    filtered_LOF_v06_analysis_df['gene_cytoband'] = list(map(lambda g: genes_to_cytobands_dict[g], list(filtered_LOF_v06_analysis_df['gene'])))
    temp_min_num_patients = 2
    filtered_LOF_v06_analysis_df = filtered_LOF_v06_analysis_df[filtered_LOF_v06_analysis_df['num_patients_used_for_test'] >= temp_min_num_patients].copy()
    # # This was me testing stuff out:
    # filtered_LOF_v06_analysis_df = filtered_LOF_v06_analysis_df[filtered_LOF_v06_analysis_df['num_patients_with_at_least_one_LOF_event'] >= temp_min_num_patients].copy()
    filtered_LOF_v06_analysis_df['q_value_LOF'] = multitest.multipletests(list(filtered_LOF_v06_analysis_df['p_value_LOF']), method = "fdr_bh")[1]
    filtered_LOF_v06_analysis_df = filtered_LOF_v06_analysis_df[['gene','num_patients_used_for_test','num_patients_with_at_least_one_LOF_event','num_total_events_used_for_test','num_intragenic_events','num_intergenic_events','num_LOF_events','prob_of_LOF','p_value_LOF','q_value_LOF','RNA_underexp_p_value','gene_cytoband']]
    # To view the significant/near-significant genes sorted by p-value from the above line:
    filtered_LOF_v06_analysis_df[filtered_LOF_v06_analysis_df['q_value_LOF'] <= 0.25].sort_values(by=['p_value_LOF']).head(1000)
else:
    # Can copy and paste what's below into ipython and see the results you want to see:
    LOF_v06_analysis_df = pd.read_csv("LOF_model_results/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_" + str(d) + "bp_v06.tsv", sep='\t')
    
    gene_list = sorted(list(set(R_mat_loaded_and_prepared_df['gene'])))
    random.seed(100) # Chose random seed number arbitrarily/randomly; it doesn't matter what it is as long as it remains the same for our analysis
    random.shuffle(gene_list)
    anonymized_ids = list(map(lambda x: 'anonymized_gene_' + str(x), list(range(0,len(gene_list)))))
    genes_to_anonymized_ids = {}
    for i in range(len(gene_list)):
        genes_to_anonymized_ids[gene_list[i]] = anonymized_ids[i]
        
    list_of_genes_from_CGC_with_connection_to_NHL_or_DLBCL = [
        "B2M","BCL2","BCL6","BCL7A","BTG2","CCND2","CDKN2A","CNTRL","CREBBP","CTNNB1","CUX1",
        "DDX6","DICER1","EIF4A2","EP300","ERBB2","EZH2","FBXO11","FCRL4","FGFR1","FGFR1OP","HIST1H4I",
        "HSP90AA1","HSP90AB1","IKZF1","IL21R","KDM6A","KDSR","LCP1","LYN","MUC1","MYC","NACA","NFKB2",
        "NOTCH2","NPM1","PAX5","PIM1","POU2AF1","PRDM1","PTPN6","RHOH","SPEN","TERT","TFRC","TP53","TP63","ZMYM2"]
    list_of_genes_bated_for_SVs_in_chapuy_et_al = [
        "ABL1","AKT3","ALK","BCL2","BCL6","BCR","BRAF","CCND1","CD274","CIITA","EGFR","ERG","ETV1","ETV6","EWSR1","FGFR1",
        "FGFR2","FGFR3","FUS","IGLL1","IGLL5","JAK2","MLL","MYC","NPM1","PAX5","PDCD1LG2","PDGFRA","PDGFRB","PPARG","RAF1",
        "RARA","RET","ROS1","SS18","TBL1XR1","TBLXR1","TERT","TMPRSS2","TP63","TRA","TRB","TRG"]
    list_of_genes_figure1a_staudt_2018_paper = [
        "CDKN2A","HLA-B","ETV6","HLA-A","IRF2BP2","PRDM1","CD58","HLA-C","SETD1B","TOX","TBL1XR1","ZEB2","FOXC1","HNRNPD",
        "LYN","KLHL14","ITPKB","ZC3H12A","ZNF292","PCNX2","GRB2","HIVEP1","UBE2O","BRCA1","KLHL42","ARHGEF1","EIF2AK3",
        "NFKBIA","POLG","UGGT2","HLA-DMB","S1PR2","SEL1L3","PARP2","PTEN","DDX3X","KLHL6","CIITA","P2RY8","GNA13",
        "EBF1","SGK1","SOCS1","B2M","CREBBP","TNFRSF14"]

    filtered_LOF_v06_analysis_df = LOF_v06_analysis_df[LOF_v06_analysis_df['num_total_events_used_for_test'] > 0]
    filtered_LOF_v06_analysis_df['RNA_underexp_p_value'] = list(map(lambda x: the_depleted_rna_df[the_depleted_rna_df['genes'] == x]['p-values'].iloc[0] if the_depleted_rna_df[the_depleted_rna_df['genes'] == x].shape[0] > 0 else "N/A", list(filtered_LOF_v06_analysis_df['gene'])))
    filtered_LOF_v06_analysis_df['gene_cytoband'] = list(map(lambda g: genes_to_cytobands_dict[g], list(filtered_LOF_v06_analysis_df['gene'])))
    filtered_LOF_v06_analysis_df['anonymized_gene'] = list(map(lambda g: genes_to_anonymized_ids[g], list(filtered_LOF_v06_analysis_df['gene'])))
    filtered_LOF_v06_analysis_df['is_DLBCL_or_NHL_TSG_or_fusion_gene_in_CGC'] = list(map(lambda g: "yes" if g in list_of_genes_from_CGC_with_connection_to_NHL_or_DLBCL else "no", list(filtered_LOF_v06_analysis_df['gene'])))
    filtered_LOF_v06_analysis_df['is_bated_SV_gene_in_chapuy_et_al'] = list(map(lambda g: "yes" if g in list_of_genes_bated_for_SVs_in_chapuy_et_al else "no", list(filtered_LOF_v06_analysis_df['gene'])))
    filtered_LOF_v06_analysis_df['is_TSG_in_figure1a_staudt_2018'] = list(map(lambda g: "yes" if g in list_of_genes_figure1a_staudt_2018_paper else "no", list(filtered_LOF_v06_analysis_df['gene'])))
    temp_min_num_patients = 2
    filtered_LOF_v06_analysis_df = filtered_LOF_v06_analysis_df[filtered_LOF_v06_analysis_df['num_patients_used_for_test'] >= temp_min_num_patients].copy()
    # # This was me testing stuff out:
    # filtered_LOF_v06_analysis_df = filtered_LOF_v06_analysis_df[filtered_LOF_v06_analysis_df['num_patients_with_at_least_one_LOF_event'] >= temp_min_num_patients].copy()
    filtered_LOF_v06_analysis_df['q_value_LOF'] = multitest.multipletests(list(filtered_LOF_v06_analysis_df['p_value_LOF']), method = "fdr_bh")[1]
    filtered_LOF_v06_analysis_df = filtered_LOF_v06_analysis_df[['anonymized_gene','is_DLBCL_or_NHL_TSG_or_fusion_gene_in_CGC','is_bated_SV_gene_in_chapuy_et_al','is_TSG_in_figure1a_staudt_2018','num_patients_used_for_test','num_patients_with_at_least_one_LOF_event',
                                                               'num_total_events_used_for_test','num_intragenic_events','num_intergenic_events','num_LOF_events','prob_of_LOF','p_value_LOF','q_value_LOF','RNA_underexp_p_value','gene_cytoband']]
    # To view the significant/near-significant genes sorted by p-value from the above line:
    filtered_LOF_v06_analysis_df[filtered_LOF_v06_analysis_df['q_value_LOF'] <= 0.25].sort_values(by=['p_value_LOF']).head(1000)
    