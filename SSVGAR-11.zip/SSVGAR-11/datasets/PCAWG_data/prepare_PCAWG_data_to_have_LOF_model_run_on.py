import pandas as pd 
import numpy as np 
import sys 
sys.path.insert(0, '/home/xloinaz/python_projects/dRangerPlus')
from dRanger_annotate_sites_prioritize_known_drivers import annotate_sites 

sys.path.insert(0, '/home/xloinaz/python_projects/dRangerPlus')

#### THIS PORTION OF THE CODE IS FOR GETTING THE PCAWG DATA INTO THE RIGHT FORMAT FOR GETTING THE DRANGER ANNOTATOR TO RUN ON:

type_of_subset = 'lymphoid'
# type_of_subset = 'lymphoma'

PCAWG_list_subset_df = pd.read_csv('merged_1.6.1.PCAWG_SV_list.' + 'subset_' + type_of_subset + '.lifted_over.csv')
PCAWG_list_subset_df.rename(columns={"donor_unique_id":"individual"},inplace=True)
PCAWG_list_subset_df = PCAWG_list_subset_df[["individual","seqnames","start","strand","altchr","altpos","altstrand"]].copy()

chr1_list = []
str1_list = []
pos1_list = []
chr2_list = []
str2_list = []
pos2_list = []
class_list = []
span_list = []
for index,row in PCAWG_list_subset_df.iterrows():
    if row['seqnames'] != row['altchr']:
        if row['seqnames'] < row['altchr']:
            chr1_ = row['seqnames']
            pos1_ = row['start']
            chr2_ = row['altchr']
            pos2_ = row['altpos']
            if row['strand'] == '+':
                str1_ = 0
            else:
                str1_ = 1
            if row['altstrand'] == '+':
                str2_ = 0
            else:
                str2_ = 1
        else:
            chr1_ = row['altchr']
            pos1_ = row['altpos']
            chr2_ = row['seqnames']
            pos2_ = row['start']
            if row['altstrand'] == '+':
                str1_ = 0
            else:
                str1_ = 1
            if row['strand'] == '+':
                str2_ = 0
            else:
                str2_ = 1
        span_ = float("NaN")
        class_ = "inter_chr"
    else:
        if row['start'] < row['altpos']:
            chr1_ = row['seqnames']
            pos1_ = row['start']
            chr2_ = row['altchr']
            pos2_ = row['altpos']
            if row['strand'] == '+':
                str1_ = 0
            else:
                str1_ = 1
            if row['altstrand'] == '+':
                str2_ = 0
            else:
                str2_ = 1
        else:
            chr1_ = row['altchr']
            pos1_ = row['altpos']
            chr2_ = row['seqnames']
            pos2_ = row['start']
            if row['altstrand'] == '+':
                str1_ = 0
            else:
                str1_ = 1
            if row['strand'] == '+':
                str2_ = 0
            else:
                str2_ = 1
        span_ = np.abs(pos2_-pos1_)
        if span_ > 10**6:
            class_ = "long_range"
        elif str1_ == str2_:
            class_ = 'inversion'
        elif str1_ == 0 and str2_ == 1:
            class_ = 'deletion'
        elif str1_ == 1 and str2_ == 0:
            class_ = 'tandem_dup'
        else:
            raise("It shouldn't be possible to get to this condition")
    chr1_list.append(chr1_)
    str1_list.append(str1_)
    pos1_list.append(pos1_)
    chr2_list.append(chr2_)
    str2_list.append(str2_)
    pos2_list.append(pos2_)
    class_list.append(class_)
    span_list.append(span_)

PCAWG_list_subset_df['chr1'] = chr1_list
PCAWG_list_subset_df['str1'] = str1_list
PCAWG_list_subset_df['pos1'] = pos1_list
PCAWG_list_subset_df['chr2'] = chr2_list
PCAWG_list_subset_df['str2'] = str2_list
PCAWG_list_subset_df['pos2'] = pos2_list
PCAWG_list_subset_df['class'] = class_list
PCAWG_list_subset_df['span'] = span_list

PCAWG_list_subset_df = PCAWG_list_subset_df[["individual","chr1","str1","pos1","chr2","str2","pos2","class","span"]].copy()



#### THIS PORTION OF THE CODE IS FOR RUNNING THE DRANGER ANNOTATOR:
P_parameters_dictionary = {}
P_parameters_dictionary['build'] = '/home/xloinaz/python_projects/dRangerPlus/relevant_R_mat_file/hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat'
P_parameters_dictionary['impute_promoters'] = True
P_parameters_dictionary['imputed_promoter_size'] = 3000
PCAWG_list_subset_df_annotated = annotate_sites(PCAWG_list_subset_df, P_parameters_dictionary)

PCAWG_list_subset_df_annotated.to_csv('merged_1.6.1.PCAWG_SV_list.' + 'subset_' + type_of_subset + '.lifted_over.annotated.tsv',sep='\t',index=False)

