import pandas as pd
import numpy as np
import scipy.io as sio
import os
from scipy import stats

def flatten_list(l):
    return [item for sublist in l for item in sublist]

def completely_flatten_list(l):
    if isinstance(l, list):
        if len(l) == 0:
            return []
        elif len(l) == 1:
            return completely_flatten_list(l[0])
        else:
            return completely_flatten_list(l[0]) + completely_flatten_list(l[1:])
    else:
        return [l]

def convert_chr_xavi(chr_val):
    # This is my own chr conversion function that takes in a chr value and converts it to an int appropriately -Xavi
    # I also made this function assuming that a human genome is being used. May have to account for other species later
    def can_convert_to_int(some_value):
        try:
            int(some_value)
            return True
        except ValueError:
            return False
    if chr_val == 'chrX':
        return 23
    elif chr_val == 'chrY':
        return 24
    elif chr_val == 'chrM':
        return 0
    elif isinstance(chr_val, str):
        if chr_val.startswith('chr'):
            return int(chr_val[3:])
        else:
            if can_convert_to_int(chr_val):
                return int(chr_val)
            else:
                raise("Invalid input value for chr")
    elif isinstance(chr_val, float):
        return int(chr_val)
    elif isinstance(chr_val, int):
        return chr_val

def load_and_prepare_R_mat_file_into_df(R_mat_file_path):
    # Below is the code for loading in the R.mat file
    # The assumption I am making is that there are 14 different columns in the following order:
    # id, transcript, chr, strand, tx_start, tx_end, code_start, code_end, n_exons, exon_starts, exon_ends, gene, exon_frames, version
    R_mat_contents = sio.loadmat(R_mat_file_path)
    data_for_R_mat_dataframe = {}
    data_for_R_mat_dataframe['id'] = np.squeeze(R_mat_contents['R'][0][0][0])
    data_for_R_mat_dataframe['transcript'] = np.array(list(map(lambda x: x[0], np.squeeze(R_mat_contents['R'][0][0][1]))))
    data_for_R_mat_dataframe['chr'] = np.array(list(map(lambda x: x[0], np.squeeze(R_mat_contents['R'][0][0][2]))))
    data_for_R_mat_dataframe['strand'] = np.array(list(map(lambda x: x[0], np.squeeze(R_mat_contents['R'][0][0][3]))))
    data_for_R_mat_dataframe['tx_start'] = np.squeeze(R_mat_contents['R'][0][0][4])
    data_for_R_mat_dataframe['tx_end'] = np.squeeze(R_mat_contents['R'][0][0][5])
    data_for_R_mat_dataframe['code_start'] = np.squeeze(R_mat_contents['R'][0][0][6])
    data_for_R_mat_dataframe['code_end'] = np.squeeze(R_mat_contents['R'][0][0][7])
    data_for_R_mat_dataframe['n_exons'] = np.squeeze(R_mat_contents['R'][0][0][8])
    data_for_R_mat_dataframe['exon_starts'] = np.array(list(map(lambda x: np.squeeze(x,axis=1), np.squeeze(R_mat_contents['R'][0][0][9]))),dtype=object)
    data_for_R_mat_dataframe['exon_ends'] = np.array(list(map(lambda x: np.squeeze(x,axis=1), np.squeeze(R_mat_contents['R'][0][0][10]))),dtype=object)
    data_for_R_mat_dataframe['gene'] = np.array(list(map(lambda x: x[0], np.squeeze(R_mat_contents['R'][0][0][11]))))
    data_for_R_mat_dataframe['exon_frames'] = np.array(list(map(lambda x: np.squeeze(x,axis=1), np.squeeze(R_mat_contents['R'][0][0][12]))),dtype=object)
    data_for_R_mat_dataframe['version'] = np.array(list(map(lambda x: x[0], np.squeeze(R_mat_contents['R'][0][0][13]))))
    # The contents below are part of load_refseq.m
    # I have not (and maybe might not do so anyway) implemented the conditionals for the build for load_refseq
    # The way I am implementing things right now is assuming that the build input is the path to an actual R.mat file, and
    # not a value like 'hg18', 'hg19', 'hg38', etc. But what's below is necessary regardless:
    # %% collapse small nucleolar RNA subtypes
    data_for_R_mat_dataframe['gene'] = np.array(list(map(lambda x: x.split('-')[0] if (x.startswith('SNORD') and '-' in x) else x, data_for_R_mat_dataframe['gene'])))
    # %% add txlen, cdlen,. protlen
    tx_len_values = np.zeros(len(R_mat_contents['R'][0][0][0]))
    code_len_values = np.zeros(len(R_mat_contents['R'][0][0][0]))
    for i in range(0,len(R_mat_contents['R'][0][0][0])):
        for e in range(0,data_for_R_mat_dataframe['n_exons'][i]):
            st = data_for_R_mat_dataframe['exon_starts'][i][e]
            en = data_for_R_mat_dataframe['exon_ends'][i][e]
            tx_len_values[i] += (en-st+1)
            if (en < data_for_R_mat_dataframe['code_start'][i]) | (st > data_for_R_mat_dataframe['code_end'][i]):
                continue
            if st < data_for_R_mat_dataframe['code_start'][i]:
                st = data_for_R_mat_dataframe['code_start'][i]
            if en > data_for_R_mat_dataframe['code_end'][i]:
                en = data_for_R_mat_dataframe['code_end'][i]
            code_len_values[i] += (en-st+1)
    n_codons_values = code_len_values / 3
    data_for_R_mat_dataframe['tx_len'] = tx_len_values
    data_for_R_mat_dataframe['code_len'] = code_len_values
    data_for_R_mat_dataframe['n_codons'] = n_codons_values

    data_for_R_mat_dataframe['chr'] = list(map(convert_chr_xavi, data_for_R_mat_dataframe['chr']))

    data_for_R_mat_dataframe['gene_start'] = data_for_R_mat_dataframe['tx_start'].copy()
    data_for_R_mat_dataframe['gene_end'] = data_for_R_mat_dataframe['tx_end'].copy()
    # if P_parameters_dictionary['impute_promoters']:
    if True:
        imputed_promoter_size = 3000
        idx = np.squeeze(np.argwhere(data_for_R_mat_dataframe['strand']=='+'))
        # data_for_R_mat_dataframe['gene_start'][idx] -= P_parameters_dictionary['imputed_promoter_size']
        data_for_R_mat_dataframe['gene_start'][idx] -= imputed_promoter_size
        idx = np.squeeze(np.argwhere(data_for_R_mat_dataframe['strand']=='-'))
        # data_for_R_mat_dataframe['gene_end'][idx] += P_parameters_dictionary['imputed_promoter_size']
        data_for_R_mat_dataframe['gene_end'][idx] += imputed_promoter_size
        
    R_mat_loaded_and_prepared_df = pd.DataFrame(data_for_R_mat_dataframe)
    return R_mat_loaded_and_prepared_df


def find_overall_exonic_and_intronic_portions_of_genome_setup(R_mat_file_path='hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat'):
    data = loadmat(R_mat_file_path)
    chr_vals = np.array(data['R']['chr'])
    start_coords = np.array(data['R']['code_start']).astype(float)
    end_coords = np.array(data['R']['code_end']).astype(float)
    exon_start_coords = list(map(lambda x: completely_flatten_list(x), (data['R']['exon_starts'])))
    exon_end_coords = list(map(lambda x: completely_flatten_list(x), (data['R']['exon_ends'])))
    genes = list(np.array(data['R']['gene']).flatten())
    gene_orientations = list(np.array(data['R']['strand']).flatten())
    # As it turns out the same gene can occur multiple times in R.mat, but I am going with the assumption that the orientation for a given gene (and its transcripts) is always the same
    dict_of_genes_and_orientations = {}
    for g_i in range(0, len(genes)):
        dict_of_genes_and_orientations[genes[g_i]] = gene_orientations[g_i]

    # This is for producing the intervals of genes:
    chr_and_start_and_end_coords = np.concatenate((chr_vals, start_coords, end_coords), axis=1)
    d = {'chr': chr_and_start_and_end_coords[:,0], 'start': chr_and_start_and_end_coords[:,1], 'end': chr_and_start_and_end_coords[:,2]}
    chr_and_start_and_end_coords_df = pd.DataFrame(data=d)
    # Need to drop any columns with nan start/end coordinates:
    chr_and_start_and_end_coords_df = chr_and_start_and_end_coords_df[(chr_and_start_and_end_coords_df['start'] != 'nan') & (chr_and_start_and_end_coords_df['end'] != 'nan')]
    chr_and_start_and_end_coords_df['start'] = np.array(chr_and_start_and_end_coords_df.copy()['start']).astype(float).astype(int)
    chr_and_start_and_end_coords_df['end'] = np.array(chr_and_start_and_end_coords_df.copy()['end']).astype(float).astype(int)
    chr_and_start_and_end_coords_df.to_csv('genes_from_updated_R_mat_file_start_and_end_coords.tsv',header=False,sep='\t',index=False)

    # This is for producing the intervals of exons:
    exon_chr_vals = []
    exon_start_coord_vals = []
    exon_end_coord_vals = []
    for i in range(0,len(chr_vals)):
        for j in range(0,len(exon_start_coords[i])):
            exon_chr_vals.append(chr_vals[i][0])
            exon_start_coord_vals.append(exon_start_coords[i][j])
            exon_end_coord_vals.append(exon_end_coords[i][j])
    d_exon = {'chr': exon_chr_vals, 'start': exon_start_coord_vals, 'end': exon_end_coord_vals}
    exon_chr_and_start_and_end_coords_df = pd.DataFrame(data=d_exon)
    exon_chr_and_start_and_end_coords_df.to_csv('exons_from_updated_R_mat_file_start_and_end_coords.tsv',header=False,sep='\t',index=False)
    # After this function (find_overall_exonic_and_intronic_portions_of_genome_setup) is run, need to run the commands from the following two files:
    # - commands_i_ran_to_get_merged_intervals_for_genes_from_R_mat_file.txt
    # - commands_i_ran_to_get_merged_intervals_for_exons_from_R_mat_file.txt
    # This allows me to work with the output of these commands for running the next find_overall_exonic_and_intronic_portions_of_genome_results



def find_overall_exonic_and_intronic_portions_of_genome_results(path_to_coding_intervals_tsv='genes_from_updated_R_mat_file_start_and_end_coords_sorted_merged.tsv', path_to_exon_intervals_tsv='exons_from_updated_R_mat_file_start_and_end_coords_sorted_merged.tsv'):
    merged_gene_intervals_df = pd.read_csv(path_to_coding_intervals_tsv, sep='\t',names=["chr", "start", "end"])
    merged_gene_intervals_df['interval width'] = merged_gene_intervals_df['end'].subtract(merged_gene_intervals_df['start'])
    span_that_gene_coding_regions_take_up = merged_gene_intervals_df['interval width'].sum()
    merged_exon_intervals_df = pd.read_csv(path_to_exon_intervals_tsv, sep='\t',names=["chr", "start", "end"])
    merged_exon_intervals_df['interval width'] = merged_exon_intervals_df['end'].subtract(merged_exon_intervals_df['start'])
    span_that_exonic_regions_take_up = merged_exon_intervals_df['interval width'].sum()
    # This is the total length of the genome for males (meaning Y is included) according to hg38:
    length_of_genome_male = 3088269832
    # This is the total length of the genome for females (meaning Y is excluded) according to hg38:
    length_of_genome_female = 3031042417
    # This is the average length of the genome (if approximately 50% of the population is male vs. female)
    length_of_genome = int(np.round(length_of_genome_male * 0.5 + length_of_genome_female * 0.5))
    proportion_of_genome_thats_intronic_or_exonic_interval = span_that_gene_coding_regions_take_up / length_of_genome
    proportion_of_genome_thats_exonic_interval = span_that_exonic_regions_take_up / length_of_genome
    proportion_of_genome_thats_intronic_interval = proportion_of_genome_thats_intronic_or_exonic_interval - proportion_of_genome_thats_exonic_interval
    return proportion_of_genome_thats_exonic_interval, proportion_of_genome_thats_intronic_interval
    

def find_probability_of_intergenic_vs_intragenic_gene_for_cohort(path_to_final_SV_list_for_analysis, threshold_of_proximity=500000, R_mat_file_path="/home/xloinaz/python_projects/GDC_DLBCL_genomes_analysis/SV_Review_and_Analysis/relevant_R_mat_file/hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat"):
    R_mat_loaded_and_prepared_df = load_and_prepare_R_mat_file_into_df(R_mat_file_path)
    SV_df = pd.read_csv(path_to_final_SV_list_for_analysis,sep='\t')
    counts_of_each_type_of_event = {'intragenic': 0, 'intergenic': 0, 'neither': 0}
    for index, row in SV_df.iterrows():
        if index % 100 == 0:
            print('index:', index)
        gene1_start_in_R_mat = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == row['gene1']]['gene_start'].min()
        gene1_end_in_R_mat = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == row['gene1']]['gene_end'].max()
        gene2_start_in_R_mat = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == row['gene2']]['gene_start'].min()
        gene2_end_in_R_mat = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == row['gene2']]['gene_end'].max()
        num_positions_too_far = 0
        if (row['pos1'] < gene1_start_in_R_mat - threshold_of_proximity) or (row['pos1'] > gene1_end_in_R_mat + threshold_of_proximity):
            num_positions_too_far += 1
        if (row['pos2'] < gene2_start_in_R_mat - threshold_of_proximity) or (row['pos2'] > gene2_end_in_R_mat + threshold_of_proximity):
            num_positions_too_far += 1
        if num_positions_too_far == 2:
            counts_of_each_type_of_event['neither'] += 1
        elif num_positions_too_far == 1:
            counts_of_each_type_of_event['intergenic'] += 1
        elif num_positions_too_far == 0:
            if row['gene1'] == row['gene2']:
                counts_of_each_type_of_event['intragenic'] += 1
            else:
                counts_of_each_type_of_event['intergenic'] += 2
        else:
            raise("Something weird had to have gone wrong")
    return counts_of_each_type_of_event
    


def find_surrounding_annotations_for_gene_with_parameters(input_gene_name, surrounding_distance_to_gene_boundary, step_size):
    file_name_based_off_input_parameters = "surrounding_annotations_for_each_gene/v02/gene_" + input_gene_name + ".surr_dist_" + str(surrounding_distance_to_gene_boundary) + "bp.step_size_" + str(step_size) + "bp.tsv"
    # check if file exists:
    if os.path.isfile(file_name_based_off_input_parameters):
        pass
    else:
        sizes_of_each_chromosome_hg38 = {1: 248956422,
                                        2: 242193529,
                                        3: 198295559,
                                        4: 190214555,
                                        5: 181538259,
                                        6: 170805979,
                                        7: 159345973,
                                        8: 145138636,
                                        9: 138394717,
                                        10: 133797422,
                                        11: 135086622,
                                        12: 133275309,
                                        13: 114364328,
                                        14: 107043718,
                                        15: 101991189,
                                        16: 90338345,
                                        17: 83257441,
                                        18: 80373285,
                                        19: 58617616,
                                        20: 64444167,
                                        21: 46709983,
                                        22: 50818468,
                                        23: 156040895, # chrX
                                        24: 57227415} # chrY
        R_mat_file_path = "/home/xloinaz/python_projects/GDC_DLBCL_genomes_analysis/SV_Review_and_Analysis/relevant_R_mat_file/hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat"
        R_mat_loaded_and_prepared_df = load_and_prepare_R_mat_file_into_df(R_mat_file_path)
        if R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == input_gene_name].empty:
            raise("Error: given gene_name is not found within R.mat file!")
        else:
            gene_chr = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == input_gene_name]['chr'].iloc[0]
            gene_start = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == input_gene_name]['gene_start'].min()
            gene_end = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == input_gene_name]['gene_end'].max()
        if gene_start - surrounding_distance_to_gene_boundary < 0:
            start_of_annotation_search = 0
        else:
            start_of_annotation_search = gene_start - surrounding_distance_to_gene_boundary
        if gene_end + surrounding_distance_to_gene_boundary > sizes_of_each_chromosome_hg38[gene_chr]:
            end_of_annotation_search = sizes_of_each_chromosome_hg38[gene_chr]
        else:
            end_of_annotation_search = gene_end + surrounding_distance_to_gene_boundary
        # Loading in the file for Cancer Gene Census genes (only translocations) and making a list out of the genes on it
        list_of_cgc_driver_transloc_genes = []
        with open("/home/xloinaz/python_projects/dRangerPlus/reference_files/COSMIC_Cancer_Gene_Census_genes_to_matched_Hugo_symbols_Dec_13_2021_only_translocations.txt") as list_of_driver_transloc_file:
            for line in list_of_driver_transloc_file:
                list_of_cgc_driver_transloc_genes.append(line.strip())
        R_mat_loaded_and_prepared_df_subset_chr = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['chr'] == gene_chr]
        counts_of_annotations_for_each_point_df = pd.DataFrame(np.zeros((1,7),dtype=int))
        counts_of_annotations_for_each_point_df.index = [input_gene_name]
        counts_of_annotations_for_each_point_df.columns = ["exon","3'UTR","5'UTR","promoter","IGR1","IGR2","not_annotated_to_gene"]
        for pos in range(start_of_annotation_search, end_of_annotation_search, step_size):
            if (pos - start_of_annotation_search) % 100000 == 0:
                print('chr: ' + str(gene_chr) + ', pos: ' + str(pos))
            overlaps_df = R_mat_loaded_and_prepared_df_subset_chr[(R_mat_loaded_and_prepared_df_subset_chr['gene_start'] <= pos) & (R_mat_loaded_and_prepared_df_subset_chr['gene_end'] >= pos)]
            # it's within a transcript: determine promoter/UTR/intron/exon
            no = overlaps_df.shape[0]
            if not no > 0:
                # it's intergenic
                dist_before = R_mat_loaded_and_prepared_df_subset_chr['tx_start'].subtract(pos).abs()
                dist_after = (-R_mat_loaded_and_prepared_df_subset_chr['tx_end']).add(pos).abs()
                for y in list(np.arange(1,3,0.3)):
                    idx = list(dist_before[dist_before <= 1000**y].index)
                    if idx:
                        i = dist_before[idx].idxmin()
                        gene_name = R_mat_loaded_and_prepared_df_subset_chr.loc[i]['gene']
                        if gene_name == input_gene_name:
                            if R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == input_gene_name]['strand'].iloc[0] == '+':
                                counts_of_annotations_for_each_point_df.loc[input_gene_name,'IGR1'] += 1
                            else:
                                counts_of_annotations_for_each_point_df.loc[input_gene_name,'IGR2'] += 1
                        else:
                            counts_of_annotations_for_each_point_df.loc[input_gene_name,'not_annotated_to_gene'] += 1
                        break
                    idx = list(dist_after[dist_after <= 1000**y].index)
                    if idx:
                        i = dist_after[idx].idxmin()
                        gene_name = R_mat_loaded_and_prepared_df_subset_chr.loc[i]['gene']
                        if gene_name == input_gene_name:
                            if R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == input_gene_name]['strand'].iloc[0] == '+':
                                counts_of_annotations_for_each_point_df.loc[input_gene_name,'IGR2'] += 1
                            else:
                                counts_of_annotations_for_each_point_df.loc[input_gene_name,'IGR1'] += 1
                        else:
                            counts_of_annotations_for_each_point_df.loc[input_gene_name,'not_annotated_to_gene'] += 1
                        break
            else:
                # Note: TBTGFC means "Transcript belongs to gene from COSMIC"
                c = np.full(no, np.nan) # zone: 1=TBTGFC+exon, 2=TBTGFC+intron, 3=TBTGFC+3'-UTR, 4=TBTGFC+5'-UTR, 5=TBTGFC+promoter, 6=exon, 7=intron, 8=3'-UTR, 9=5'-UTR, 10=promoter
                d = np.full(no, np.nan) # for exons: which one, and how far
                d1 = np.full(no, np.nan) # for introns: between which exons and how far?
                d2 = np.full(no, np.nan) # for introns: between which exons and how far?
                e1 = np.full(no, np.nan) # for introns: between which exons and how far?
                for j in range(0,no):
                    i = overlaps_df.index[j]
                    gene_name = R_mat_loaded_and_prepared_df.loc[i]['gene']
                    # is contained in the list of COSMIC driver genes with differing transcripts?
                    addend_for_if_not_TBTGFC = 0
                    if not gene_name in list_of_cgc_driver_transloc_genes:
                        addend_for_if_not_TBTGFC = 5
                    # in promoter?
                    if pos < R_mat_loaded_and_prepared_df.loc[i]['tx_start']:
                        c[j] = 5 + addend_for_if_not_TBTGFC
                        d[j] = R_mat_loaded_and_prepared_df.loc[i]['tx_start'] - pos
                        continue
                    if pos > R_mat_loaded_and_prepared_df.loc[i]['tx_end']:
                        c[j] = 5 + addend_for_if_not_TBTGFC
                        d[j] = pos - R_mat_loaded_and_prepared_df.loc[i]['tx_end']
                        continue
                    # in UTR?
                    if R_mat_loaded_and_prepared_df.loc[i]['strand'] == '+':
                        if R_mat_loaded_and_prepared_df.loc[i]['code_start'] > pos:
                            c[j] = 4 + addend_for_if_not_TBTGFC
                            d[j] = R_mat_loaded_and_prepared_df.loc[i]['code_start'] - pos
                            continue
                        if R_mat_loaded_and_prepared_df.loc[i]['code_end'] < pos:
                            c[j] = 3 + addend_for_if_not_TBTGFC
                            d[j] = pos-R_mat_loaded_and_prepared_df.loc[i]['code_end']
                            continue
                    else: # (-)
                        if R_mat_loaded_and_prepared_df.loc[i]['code_start'] > pos:
                            c[j] = 3 + addend_for_if_not_TBTGFC
                            d[j] = R_mat_loaded_and_prepared_df.loc[i]['code_start'] - pos
                            continue
                        if R_mat_loaded_and_prepared_df.loc[i]['code_end'] < pos:
                            c[j] = 4 + addend_for_if_not_TBTGFC
                            d[j] = pos-R_mat_loaded_and_prepared_df.loc[i]['code_end']
                            continue
                    # in exon(s)?
                    in_e = list(np.array(range(1,len(R_mat_loaded_and_prepared_df.loc[i]['exon_starts'])+1))[(R_mat_loaded_and_prepared_df.loc[i]['exon_starts'] <= pos) & (R_mat_loaded_and_prepared_df.loc[i]['exon_ends'] >= pos)])
                    if in_e:
                        c[j] = 1 + addend_for_if_not_TBTGFC
                        continue
                    # otherwise: in intron
                    c[j] = 2 + addend_for_if_not_TBTGFC
                    for k in range(0, R_mat_loaded_and_prepared_df.loc[i]['n_exons']-1):
                        if (R_mat_loaded_and_prepared_df.loc[i]['exon_ends'][k] < pos) and (R_mat_loaded_and_prepared_df.loc[i]['exon_starts'][k+1] > pos):
                            e1[j] = k+1
                            d1[j] = pos - R_mat_loaded_and_prepared_df.loc[i]['exon_ends'][k]
                            d2[j] = R_mat_loaded_and_prepared_df.loc[i]['exon_starts'][k+1] - pos
                            d[j] = min(d1[j], d2[j])
                            break
                
                # % find the transcript in the highest-priority class
                zone = -1
                for cidx in list(range(1,11)):
                    idx = [z for z in range(len(c)) if c[z] == cidx]
                    if not idx:
                        continue
                    if cidx == 1 or cidx == 6:
                        j = j = idx[0]
                    else:
                        k = np.argmin(d[np.array(idx)])
                        j = idx[k]
                    i = overlaps_df.index[j]
                    name = R_mat_loaded_and_prepared_df.loc[i]['gene']
                    strand = R_mat_loaded_and_prepared_df.loc[i]['strand']
                    if strand == '-':
                        e1[j] = R_mat_loaded_and_prepared_df.loc[i]['n_exons'] - e1[j] + 1
                    zone = cidx
                    if zone == 1 or zone == 6:
                        which_column = "exon"
                    elif zone == 2 or zone == 7:
                        intronnum = e1[j]
                        which_column = "intron" + str(int(intronnum))
                    elif zone == 3 or zone == 8:
                        which_column = "3'UTR"
                    elif zone == 4 or zone == 9:
                        which_column = "5'UTR"
                    elif zone == 5 or zone == 10:
                        which_column = "promoter"
                    else:
                        raise('zone variable is not what it should be')
                    if name == input_gene_name:
                        if not which_column in list(counts_of_annotations_for_each_point_df.columns):
                            counts_of_annotations_for_each_point_df[which_column] = 0
                        counts_of_annotations_for_each_point_df.loc[input_gene_name,which_column] += 1
                    else:
                        counts_of_annotations_for_each_point_df.loc[input_gene_name,"not_annotated_to_gene"] += 1
                    break
        counts_of_annotations_for_each_point_df.to_csv(file_name_based_off_input_parameters,sep='\t',index=False)



def find_surrounding_annotations_for_gene_with_parameters_for_list_of_input_genes(list_of_input_genes, surrounding_distance_to_gene_boundary, step_size):
    for g in list_of_input_genes:
        print('Gene:', g)
        find_surrounding_annotations_for_gene_with_parameters(g, surrounding_distance_to_gene_boundary, step_size)


def find_probability_of_LOF_for_a_given_gene(gene, \
                                             path_for_annotations_surrounding_gene, \
                                             path_to_final_SV_list_for_analysis, \
                                             overall_proportion_of_genome_thats_exonic_interval, \
                                             # calculated via find_overall_exonic_and_intronic_portions_of_genome_results()[0]
                                             overall_proportion_of_genome_thats_intronic_interval, \
                                             # calculated via find_overall_exonic_and_intronic_portions_of_genome_results()[1]
                                             prob_of_intragenic, \
                                             prob_of_intergenic, \
                                             table_for_intragenic_unlikely_vs_likely_LOF_path="table_of_likely_LOF_vs_unlikely_LOF_for_intragenic_events_v02.tsv"):
    # # prob_of_intragenic and prob_of_intergenic can be calculated via the following 5 lines of code:
    # counts_of_each_type_of_event = find_probability_of_intergenic_vs_intragenic_gene_for_cohort(path_to_final_SV_list_for_analysis, threshold_of_proximity, R_mat_file_path)
    # overall_count_of_intragenic = counts_of_each_type_of_event['intragenic']
    # overall_count_of_intergenic = counts_of_each_type_of_event['intergenic']
    # prob_of_intragenic = overall_count_of_intragenic / (overall_count_of_intragenic + overall_count_of_intergenic)
    # prob_of_intergenic = overall_count_of_intergenic / (overall_count_of_intragenic + overall_count_of_intergenic)

    if gene != ".".join(path_for_annotations_surrounding_gene.split('/')[-1].split('.')[:-3]).split('_')[1]:
        raise("Gene doesn't correspond to the path for the surrounding annotations .tsv file!")

    gene_regions_mini_df = pd.read_csv(path_for_annotations_surrounding_gene,sep='\t')

    intron_columns = list(filter(lambda x: x.startswith("intron"), list(gene_regions_mini_df.columns)))
    total_length_annotated_to_gene_within_threshold = gene_regions_mini_df.iloc[0]["exon"] + gene_regions_mini_df.iloc[0]["3'UTR"] + gene_regions_mini_df.iloc[0]["5'UTR"] + gene_regions_mini_df.iloc[0]["promoter"] + gene_regions_mini_df.iloc[0]["IGR1"] + gene_regions_mini_df.iloc[0]["IGR2"]
    total_num_annotations_for_introns = 0
    for intr_col in intron_columns:
        total_length_annotated_to_gene_within_threshold += gene_regions_mini_df.iloc[0][intr_col]
        total_num_annotations_for_introns += gene_regions_mini_df.iloc[0][intr_col]
    # Find probability of LOF for intragenic events:
    table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df = pd.read_csv(table_for_intragenic_unlikely_vs_likely_LOF_path,'\t')
    table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.set_index('Placement of breakpoints',inplace=True)
    table_of_intragenic_events_probabilities_df = pd.DataFrame(data=np.zeros((table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.shape[0],table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.shape[1])),\
                                                                index=table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.index,
                                                                columns=table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.columns)

    probability_of_events_happening_with_same_intron_given_both_bp_in_intron = np.sum(list(map(lambda intr_col: (gene_regions_mini_df.iloc[0][intr_col] / total_num_annotations_for_introns)**2, intron_columns)))
    for index, row in table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.iterrows():
        print('index:', index)
        probability_reduction_factor = 1
        if '(in-frame)' in index:
            probability_reduction_factor = 1/3
        elif '(out-of-frame)' in index:
            probability_reduction_factor = 2/3
        first_region = index.split(' ')[0].split('-')[0]
        second_region = index.split(' ')[0].split('-')[1]
        if first_region == 'intron' and second_region == 'intron':
            probability_reduction_factor *= (1-probability_of_events_happening_with_same_intron_given_both_bp_in_intron)
        if first_region.startswith('intron'):
            factor1_for_product_for_probability = total_num_annotations_for_introns / total_length_annotated_to_gene_within_threshold
        else:
            factor1_for_product_for_probability = gene_regions_mini_df.iloc[0][first_region] / total_length_annotated_to_gene_within_threshold
        if second_region.startswith('intron'):
            factor2_for_product_for_probability = total_num_annotations_for_introns / total_length_annotated_to_gene_within_threshold
        else:
            factor2_for_product_for_probability = gene_regions_mini_df.iloc[0][second_region] / total_length_annotated_to_gene_within_threshold
        if first_region == second_region:
            probability_of_event_no_matter_bp_orientations = factor1_for_product_for_probability * factor2_for_product_for_probability
        else:
            probability_of_event_no_matter_bp_orientations = 2 * factor1_for_product_for_probability * factor2_for_product_for_probability
        if not '(within same intron)' in index:
            table_of_intragenic_events_probabilities_df.loc[index, 'Deletion cases'] = probability_of_event_no_matter_bp_orientations * 0.25 * probability_reduction_factor
            table_of_intragenic_events_probabilities_df.loc[index, 'Tandem duplication cases'] = probability_of_event_no_matter_bp_orientations * 0.25 * probability_reduction_factor
            table_of_intragenic_events_probabilities_df.loc[index, 'Inversions cases'] = probability_of_event_no_matter_bp_orientations * 0.5 * probability_reduction_factor
        else:
            table_of_intragenic_events_probabilities_df.loc[index, 'Deletion cases'] = probability_of_event_no_matter_bp_orientations * 0.25 * probability_of_events_happening_with_same_intron_given_both_bp_in_intron
            table_of_intragenic_events_probabilities_df.loc[index, 'Tandem duplication cases'] = probability_of_event_no_matter_bp_orientations * 0.25 * probability_of_events_happening_with_same_intron_given_both_bp_in_intron
            table_of_intragenic_events_probabilities_df.loc[index, 'Inversions cases'] = probability_of_event_no_matter_bp_orientations * 0.5 * probability_of_events_happening_with_same_intron_given_both_bp_in_intron
    p_LOF_intragenic = 0
    for index, row in table_of_intragenic_events_probabilities_df.iterrows():
        for col_name in list(table_of_intragenic_events_probabilities_df.columns):
            if table_of_intragenic_events_labeled_unlikely_vs_likely_LOF_df.loc[index,col_name] == 'LL':
                p_LOF_intragenic += row[col_name]

    # Find probability of LOF for intergenic events:
    p_LOF_intergenic = (gene_regions_mini_df.iloc[0]["exon"] / total_length_annotated_to_gene_within_threshold) * (1 - (1/6)*(overall_proportion_of_genome_thats_exonic_interval)) + (total_num_annotations_for_introns / total_length_annotated_to_gene_within_threshold) * (1 - (1/6)*(overall_proportion_of_genome_thats_intronic_interval))

    # # Horrible mistake in my code that I had before:
    # return p_LOF_intergenic * prob_of_intragenic + p_LOF_intergenic * prob_of_intergenic
    # Corrected:
    return p_LOF_intragenic * prob_of_intragenic + p_LOF_intergenic * prob_of_intergenic


def compute_LOF_significance_for_gene(gene, path_to_final_SV_list_for_analysis, probability_of_LOF_for_gene_for_binomial_test, R_mat_loaded_and_prepared_df, table_for_intragenic_unlikely_vs_likely_LOF_path="table_of_likely_LOF_vs_unlikely_LOF_for_intragenic_events_v02.tsv", threshold_of_proximity=500000):
    SV_list_df_original = pd.read_csv(path_to_final_SV_list_for_analysis,sep='\t')
    list_of_SV_events_annotated_to_gene_without_threshold_of_proximity_applied_df = SV_list_df_original[(SV_list_df_original['gene1'] == gene) | (SV_list_df_original['gene2'] == gene)]
    num_events_total_within_threshold_of_proximity = 0
    num_events_skipped = 0
    num_intragenic_events = 0
    num_intergenic_events = 0
    num_events_LOF = 0
    for index,row in list_of_SV_events_annotated_to_gene_without_threshold_of_proximity_applied_df.iterrows():
        print('index:', index)
        gene_start_in_R_mat = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['gene_start'].min()
        gene_end_in_R_mat = R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['gene_end'].max()
        pos_that_should_correspond_to_gene = [True,True]
        if (row['pos1'] < gene_start_in_R_mat - threshold_of_proximity) or (row['pos1'] > gene_end_in_R_mat + threshold_of_proximity) or row['gene1'] != gene:
            pos_that_should_correspond_to_gene[0] = False
        if (row['pos2'] < gene_start_in_R_mat - threshold_of_proximity) or (row['pos2'] > gene_end_in_R_mat + threshold_of_proximity) or row['gene2'] != gene:
            pos_that_should_correspond_to_gene[1] = False
        if pos_that_should_correspond_to_gene[0] == False and pos_that_should_correspond_to_gene[1] == False: # should not be counted as an event for this gene
            num_events_skipped += 1
            continue
        elif pos_that_should_correspond_to_gene[0] == False or pos_that_should_correspond_to_gene[1] == False: # intergenic case
            num_events_total_within_threshold_of_proximity += 1
            num_intergenic_events += 1
            if pos_that_should_correspond_to_gene[0]:
                if ((row['site1'].lower().startswith('intron')) and (not "in frame" in row['fusion'].lower())) or ((row['site1'].lower().startswith('exon')) and (not "in frame" in row['fusion'].lower())):
                    num_events_LOF += 1
            elif pos_that_should_correspond_to_gene[1]:
                if ((row['site2'].lower().startswith('intron')) and (not "in frame" in row['fusion'].lower())) or ((row['site2'].lower().startswith('exon')) and (not "in frame" in row['fusion'].lower())):
                    num_events_LOF += 1
        else: # intragenic case
            num_events_total_within_threshold_of_proximity += 1
            num_intragenic_events += 1
            annotation_for_each_bp = []
            for i in [1,2]:
                site_annotation = row["site"+str(i)]
                print('site_annotation:')
                print(site_annotation)
                if site_annotation.lower().startswith("exon"):
                    annotation_for_each_bp.append("exon")
                elif site_annotation.lower().startswith("intron"):
                    annotation_for_each_bp.append("intron")
                elif site_annotation.lower().startswith("3'-utr"):
                    annotation_for_each_bp.append("3'UTR")
                elif site_annotation.lower().startswith("5'-utr"):
                    annotation_for_each_bp.append("5'UTR")
                elif site_annotation.lower().startswith("promoter"):
                    annotation_for_each_bp.append("promoter")
                # I am assuming that if our position here is before any gene start in the R.mat file for that gene that it cannot take place after the gene the transcript that is used for the position's acutal annotation
                elif (site_annotation.lower().startswith("igr") and (row['pos'+str(i)] <= R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['gene_start']).any() and R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['strand'].iloc[0] == '+') or \
                     (site_annotation.lower().startswith("igr") and (row['pos'+str(i)] >= R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['gene_end']).any() and R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['strand'].iloc[0] == '-'):
                    print('YEAH, THIS CONDITION 1 WAS CARRIED OUT!!!!')
                    annotation_for_each_bp.append("IGR1")
                elif (site_annotation.lower().startswith("igr") and (row['pos'+str(i)] >= R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['gene_end']).any() and R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['strand'].iloc[0] == '+') or \
                     (site_annotation.lower().startswith("igr") and (row['pos'+str(i)] <= R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['gene_start']).any() and R_mat_loaded_and_prepared_df[R_mat_loaded_and_prepared_df['gene'] == gene]['strand'].iloc[0] == '-'):
                    print('YEAH, THIS CONDITION 2 WAS CARRIED OUT!!!!')
                    annotation_for_each_bp.append("IGR2")
                else:
                    raise("Seemingly we have a site annotation outside of all the possibilities we accounted for... something is wrong here.")
            annotation_for_each_bp[0] + "-" + annotation_for_each_bp[1]
            table_for_intragenic_unlikely_vs_likely_LOF_df = pd.read_csv(table_for_intragenic_unlikely_vs_likely_LOF_path,sep='\t')
            table_for_intragenic_unlikely_vs_likely_LOF_df_binary = table_for_intragenic_unlikely_vs_likely_LOF_df.replace('UL',0).replace('LL',1)
            sub_df = table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'].str.contains(annotation_for_each_bp[0] + "-" + annotation_for_each_bp[1]) | table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'].str.contains(annotation_for_each_bp[1] + "-" + annotation_for_each_bp[0])]
            if row['str1'] == 1 and row['str2'] == 0:
                column_label_for_type_of_event = 'Tandem duplication cases' # tandem duplication case
            elif row['str1'] == 0 and row['str2'] == 1:
                column_label_for_type_of_event = 'Deletion cases' # deletion case
            else:
                column_label_for_type_of_event = 'Inversions cases' # inversion case
            if sub_df.shape[0] == 0:
                raise("No corresponding events found in table of unlikely vs. likely LOF")
            if sub_df.shape[0] == 1:
                num_events_LOF += sub_df.iloc[0][column_label_for_type_of_event]
            else:
                if annotation_for_each_bp[0] + "-" + annotation_for_each_bp[1] == "exon-intron" or annotation_for_each_bp[1] + "-" + annotation_for_each_bp[0] == "exon-intron":
                    if "in frame" in row['fusion']:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'exon-intron (in-frame)'][column_label_for_type_of_event].iloc[0]
                    else:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'exon-intron (out-of-frame)'][column_label_for_type_of_event].iloc[0]
                if annotation_for_each_bp[0] + "-" + annotation_for_each_bp[1] == "exon-exon":
                    if "in frame" in row['fusion']:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'exon-exon (in-frame)'][column_label_for_type_of_event].iloc[0]
                    else:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'exon-exon (out-of-frame)'][column_label_for_type_of_event].iloc[0]
                if annotation_for_each_bp[0] + "-" + annotation_for_each_bp[1] == "intron-intron":
                    if "within intron" in row['fusion']:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'intron-intron (within same intron)'][column_label_for_type_of_event].iloc[0]
                    elif "in frame" in row['fusion']:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'intron-intron (in-frame)'][column_label_for_type_of_event].iloc[0]
                    else:
                        num_events_LOF += table_for_intragenic_unlikely_vs_likely_LOF_df_binary[table_for_intragenic_unlikely_vs_likely_LOF_df_binary['Placement of breakpoints'] == 'intron-intron (out-of-frame)'][column_label_for_type_of_event].iloc[0]
                

    p_value_for_LOF_test = stats.binom_test(num_events_LOF, n=num_events_total_within_threshold_of_proximity, p=probability_of_LOF_for_gene_for_binomial_test, alternative='greater')

    print("Gene:", gene)
    print("Number of intragenic events:", num_intragenic_events)
    print("Number of intergenic events:", num_intergenic_events)
    print("Number of events skipped:", num_events_skipped)
    print("Number of total events (with at least one breakpoint within threshold of proximity of gene):", num_events_total_within_threshold_of_proximity)
    print("Number of LOF events by criteria of model:", num_events_LOF)
    print("Computed probability of LOF used for binomial test:", probability_of_LOF_for_gene_for_binomial_test)
    print("p-value for LOF:", p_value_for_LOF_test)
    return pd.DataFrame(data={'gene': [gene], 'num_total_events_used_for_test': [num_events_total_within_threshold_of_proximity], 'num_intragenic_events': [num_intragenic_events], 'num_intergenic_events': [num_intergenic_events], 'num_LOF_events': [num_events_LOF], 'prob_of_LOF': [probability_of_LOF_for_gene_for_binomial_test], 'p_value_LOF': [p_value_for_LOF_test]})
    

def perform_LOF_test_for_list_of_genes(list_of_genes, \
                                       path_to_final_SV_list_for_analysis, \
                                       path_to_directory_for_annotations_surrounding_gene, \
                                       threshold_of_proximity=500000, \
                                       step_size_for_annotating_gene_regions=10, \
                                       R_mat_file_path="/home/xloinaz/python_projects/GDC_DLBCL_genomes_analysis/SV_Review_and_Analysis/relevant_R_mat_file/hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat", \
                                       table_for_intragenic_unlikely_vs_likely_LOF_path="table_of_likely_LOF_vs_unlikely_LOF_for_intragenic_events_v02.tsv"):
    
    R_mat_loaded_and_prepared_df = load_and_prepare_R_mat_file_into_df(R_mat_file_path)
    
    overall_proportion_of_genome_thats_exonic_interval = find_overall_exonic_and_intronic_portions_of_genome_results()[0]
    overall_proportion_of_genome_thats_intronic_interval = find_overall_exonic_and_intronic_portions_of_genome_results()[1]
    
    counts_of_each_type_of_event = find_probability_of_intergenic_vs_intragenic_gene_for_cohort(path_to_final_SV_list_for_analysis, threshold_of_proximity=threshold_of_proximity, R_mat_file_path=R_mat_file_path)
    overall_count_of_intragenic = counts_of_each_type_of_event['intragenic']
    overall_count_of_intergenic = counts_of_each_type_of_event['intergenic']
    prob_of_intragenic = overall_count_of_intragenic / (overall_count_of_intragenic + overall_count_of_intergenic)
    prob_of_intergenic = overall_count_of_intergenic / (overall_count_of_intragenic + overall_count_of_intergenic)
    
    dfs_to_be_concatted = []
    index_for_reindexing = 0
    for gene in list_of_genes:
        print("Gene:", gene)
        path_for_annotations_surrounding_gene = path_to_directory_for_annotations_surrounding_gene + "/gene_" + gene + ".surr_dist_" + str(threshold_of_proximity) + "bp.step_size_" + str(step_size_for_annotating_gene_regions) + "bp.tsv"
        prob_LOF_based_off_gene = find_probability_of_LOF_for_a_given_gene(gene, \
                                                 path_for_annotations_surrounding_gene, \
                                                 path_to_final_SV_list_for_analysis, \
                                                 overall_proportion_of_genome_thats_exonic_interval=overall_proportion_of_genome_thats_exonic_interval, \
                                                 overall_proportion_of_genome_thats_intronic_interval=overall_proportion_of_genome_thats_intronic_interval, \
                                                 prob_of_intragenic=prob_of_intragenic, \
                                                 prob_of_intergenic=prob_of_intergenic, \
                                                 table_for_intragenic_unlikely_vs_likely_LOF_path=table_for_intragenic_unlikely_vs_likely_LOF_path)

        row_for_LOF_test_for_gene_df = compute_LOF_significance_for_gene(gene, \
                                                                         path_to_final_SV_list_for_analysis, \
                                                                         prob_LOF_based_off_gene, \
                                                                         R_mat_loaded_and_prepared_df, \
                                                                         table_for_intragenic_unlikely_vs_likely_LOF_path="table_of_likely_LOF_vs_unlikely_LOF_for_intragenic_events_v02.tsv", \
                                                                         threshold_of_proximity=threshold_of_proximity)
        row_for_LOF_test_for_gene_df.index = [index_for_reindexing]
        dfs_to_be_concatted.append(row_for_LOF_test_for_gene_df)
        index_for_reindexing += 1
    
    concatted_df = pd.concat(dfs_to_be_concatted).sort_values(by=['num_total_events_used_for_test'])
    return concatted_df

if __name__ == '__main__':
    # SV_list_df_with_16_low_purity_patients_removed = pd.read_csv('All_Pairs.dRanger_etc.filtered_SV.columns_subset_enhanced_genes_100000bp_with_annotations.tsv',sep='\t')
    # all_740_genes_with_at_least_2_patients_with_corresponding_SVs = []
    # for unique_gene in set(list(SV_list_df_with_16_low_purity_patients_removed['gene1']) + list(SV_list_df_with_16_low_purity_patients_removed['gene2'])):
    #     if len(set(SV_list_df_with_16_low_purity_patients_removed[(SV_list_df_with_16_low_purity_patients_removed['gene1'] == unique_gene) | (SV_list_df_with_16_low_purity_patients_removed['gene2'] == unique_gene)]['individual'])) >= 2:
    #         all_740_genes_with_at_least_2_patients_with_corresponding_SVs.append(unique_gene)
    
    version = "v02"
    
    all_740_genes_with_at_least_2_patients_with_corresponding_SVs = []
    with open('list_of_genes_annotated_to_SVs_recurring_across_at_least_2_patients.txt') as list_file:
        for line in list_file:
            all_740_genes_with_at_least_2_patients_with_corresponding_SVs.append(line.strip())

    for d in [0,50000,100000,200000,500000]:
        results_df = perform_LOF_test_for_list_of_genes(list_of_genes=all_740_genes_with_at_least_2_patients_with_corresponding_SVs, \
                                        path_to_final_SV_list_for_analysis='All_Pairs.dRanger_etc.filtered_SV.columns_subset_enhanced_genes_100000bp_with_annotations.tsv', \
                                        path_to_directory_for_annotations_surrounding_gene='surrounding_annotations_for_each_gene/' + version, \
                                        threshold_of_proximity=d)
        results_df.to_csv("LOF_model_results/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_" + str(d) + "bp" + "_" + version + ".tsv", sep='\t',index=False)
        
        
        ## Could perform patient filtration and the multiple test correction and see what those results are and also save those.
        ## Can do it for all distance threshold d's, and also filtration for minimum # of patients
