import pandas as pd
import os

### NEED TO SPECIFY A PROJECT FOR WHICH YOU ARE RUNNING:
project = "CTSP_DLBCL" # possible projects right now: CTSP_DLBCL, JB_MM_SU2C, PCAWG_lymphoma, PCAWG_lymphoid
directory_to_save_lists_of_genes_annotated_to_SVs_recurrent_across_at_least_2_patients = "../lists_of_genes_annotated_to_SVs_recurring_across_at_least_2_patients_for_cohorts/v11/" + project
os.makedirs(directory_to_save_lists_of_genes_annotated_to_SVs_recurrent_across_at_least_2_patients)

if project == "CTSP_DLBCL":
    # This is for CTSP DLBCL data:
    filename = directory_to_save_lists_of_genes_annotated_to_SVs_recurrent_across_at_least_2_patients + "/list_of_genes_annotated_to_SVs_recurring_across_at_least_2_patients.109_FF_pairs.txt"
    SV_df = pd.read_csv('../datasets/' + project + '/All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv',sep='\t')
elif project == "PCAWG_lymphoid":
    # This is for PCAWG lymphoid data:
    filename = directory_to_save_lists_of_genes_annotated_to_SVs_recurrent_across_at_least_2_patients + "/list_of_genes_annotated_to_SVs_recurring_across_at_least_2_patients.PCAWG_data_lymphoid.txt"
    SV_df = pd.read_csv('../datasets/' + project + '/merged_1.6.1.PCAWG_SV_list.subset_lymphoid.lifted_over.annotated.tsv',sep='\t')
elif project == "PCAWG_lymphoma":
    # This is for PCAWG lymphoma data:
    filename = directory_to_save_lists_of_genes_annotated_to_SVs_recurrent_across_at_least_2_patients + "/list_of_genes_annotated_to_SVs_recurring_across_at_least_2_patients.PCAWG_data_lymphoma.txt"
    SV_df = pd.read_csv('../datasets/' + project + '/merged_1.6.1.PCAWG_SV_list.subset_lymphoma.lifted_over.annotated.tsv',sep='\t')
elif project == "JB_MM_SU2C":
    # This is for JB multiple myeloma SU2C data:
    filename = directory_to_save_lists_of_genes_annotated_to_SVs_recurrent_across_at_least_2_patients + "/list_of_genes_annotated_to_SVs_recurring_across_at_least_2_patients.JB_multiple_myeloma_SU2C.txt"
    SV_df = pd.read_csv('../datasets/' + project + '/20230509_MMRF_SU2C_MARK_OW_SV_filtered_results_baseline_hg38_sd_gt_0.annotated.tsv',sep='\t')

unique_genes = list(set(list(SV_df['gene1']) + list(SV_df['gene2'])))
counts_of_patients_corresponding_to_unique_genes = list(map(lambda x: len(set(SV_df[(SV_df['gene1'] == x) | (SV_df['gene2'] == x)]['individual'])), unique_genes))
genes_to_counts_of_patients = {}
for i in range(len(unique_genes)):
    genes_to_counts_of_patients[unique_genes[i]] = counts_of_patients_corresponding_to_unique_genes[i]
ordered_genes_that_recur_across_at_least_2_patients = list(map(lambda z: z[0], list(filter(lambda y: y[1] > 1, sorted(genes_to_counts_of_patients.items(),key = lambda x: x[1],reverse=True)))))

# Produce .txt file:
file_to_create = open(filename, "w")
for gene in ordered_genes_that_recur_across_at_least_2_patients:
    file_to_create.write(gene + "\n")
file_to_create.close()

