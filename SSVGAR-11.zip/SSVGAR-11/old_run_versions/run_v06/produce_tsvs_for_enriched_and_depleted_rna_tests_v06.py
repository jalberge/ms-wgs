import pandas as pd
from qtl import annotation
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test import produce_p_values_for_genes_enriched_and_depleted




SV_df = pd.read_csv("All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv",sep='\t')
annot_v36 = annotation.Annotation("gencode.v36.annotation.gtf")
the_enriched_rna_df, the_depleted_rna_df = produce_p_values_for_genes_enriched_and_depleted(annot_v36, "All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv")


the_enriched_rna_df.to_csv("enriched_rna_wilcoxon_tsv_v06.tsv",sep='\t',index=False)
the_depleted_rna_df.to_csv("depleted_rna_wilcoxon_tsv_v06.tsv",sep='\t',index=False)

