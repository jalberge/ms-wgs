import pandas as pd 
import numpy as np 


orig_PCAWG_SV_list_df = pd.read_csv('merged_1.6.1.PCAWG_SV_list.csv')
histology_df = pd.read_csv('pcawg_specimen_histology_August2016_v6.tsv',sep='\t')

# Getting a subset of the histology dataframe:
histology_df_subset = histology_df[(histology_df['histology_abbreviation'].str.contains('Lymph')) & \
                                   (histology_df['specimen_library_strategy'].str.contains('WGS')) & \
                                   (histology_df['donor_wgs_included_excluded'] == 'Included')]


# type_of_subset = 'lymphoid'
type_of_subset = 'lymphoma'

if type_of_subset == 'lymphoid':
    list_of_relevant_donor_ids = list(histology_df_subset['donor_unique_id'])
    print(len(list_of_relevant_donor_ids))
    print(len(set(list_of_relevant_donor_ids)))
elif type_of_subset == 'lymphoma':
    list_of_relevant_donor_ids = list(histology_df_subset[(histology_df_subset['histology_abbreviation'] == 'Lymph-BNHL') | 
                                                          (histology_df_subset['histology_abbreviation'] == 'Lymph-NOS')]['donor_unique_id'])
    print(len(list_of_relevant_donor_ids))
    print(len(set(list_of_relevant_donor_ids)))
else:
    raise("We haven't made such an option for subsetting the SV list")


subsetted_SV_list_df = orig_PCAWG_SV_list_df[orig_PCAWG_SV_list_df['donor_unique_id'].isin(list_of_relevant_donor_ids)]
subsetted_SV_list_df.to_csv('merged_1.6.1.PCAWG_SV_list.' + 'subset_' + type_of_subset + '.csv', index=False)
