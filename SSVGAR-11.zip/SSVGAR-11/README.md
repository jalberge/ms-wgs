# SSVGAR
SSVGAR: Significant Structural Variant Genic Association Revelation (pronounced "sugar"). 

Was formerly called SVGAR_sf (Structural Variant Gene Annotation-Related significance finder; prononunced "sugar S.F."). 

Note: File paths used within the Python files for versions of v01 to v06 of the model (within the folder "old_versions") may not be updated and there are no directions for how to run these models. But these things should be OK as we don't use those versions of the model anymore.
