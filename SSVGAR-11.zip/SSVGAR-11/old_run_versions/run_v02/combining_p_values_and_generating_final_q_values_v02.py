import numpy as np
import pandas as pd
import scipy.stats
from statsmodels.stats import multitest
from qtl import annotation
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test import produce_p_values_for_genes_enriched_and_depleted

LOF_v02_analysis_df = pd.read_csv('LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients.tsv',sep='\t') # This was produced by literally just running "python SV_analysis_loss_of_function_events_v02.py"
annot_v36 = annotation.Annotation("gencode.v36.annotation.gtf")
enriched_rna_df, depleted_rna_df = produce_p_values_for_genes_enriched_and_depleted(annot_v36, "All_Pairs.dRanger_etc.filtered_SV.columns_subset_enhanced_genes_100000bp_with_annotations.tsv")
merged_df = depleted_rna_df.merge(LOF_v02_analysis_df,left_on='genes',right_on='gene').drop(columns=['gene','q-values']).rename(columns={"num_total_events_used_for_test": "num_total_events_used_for_LOF_test", "p-values": "p_value_RNA_underexp"})
cols_for_merged_df = list(merged_df.columns)
cols_for_merged_df.remove('p_value_RNA_underexp')
merged_df = merged_df[cols_for_merged_df + ['p_value_RNA_underexp']]

min_num_patients = 5
merged_df = merged_df[merged_df["Number of patients"] >= min_num_patients].copy()
merged_df['combined_p_value'] = list(map(lambda x: scipy.stats.combine_pvalues([x[0],x[1]],method='fisher')[1], zip(list(merged_df['p_value_RNA_underexp']), list(merged_df['p_value_LOF']))))
merged_df['q_value'] = multitest.multipletests(list(merged_df['combined_p_value']), method = "fdr_bh")[1]
merged_df.sort_values(['q_value','combined_p_value'], ascending=[True,True], inplace=True)


