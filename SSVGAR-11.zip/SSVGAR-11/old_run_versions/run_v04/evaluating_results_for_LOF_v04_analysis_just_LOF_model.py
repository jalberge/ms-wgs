import pandas as pd
import numpy as np
from statsmodels.stats import multitest
from qtl import annotation
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test import produce_p_values_for_genes_enriched_and_depleted

SV_df = pd.read_csv("All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv",sep='\t')
annot_v36 = annotation.Annotation("gencode.v36.annotation.gtf")
the_enriched_rna_df, the_depleted_rna_df = produce_p_values_for_genes_enriched_and_depleted(annot_v36, "All_Pairs.dRanger_etc.filtered_SV.109_pairs.with_tumor_submitter_id.16_low_purity_samples_removed.tsv")

# Need to set d (surrounding window threshold):
d = 1000000

LOF_v04_analysis_df = pd.read_csv("LOF_model_results/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_" + str(d) + "bp_v04.tsv", sep='\t')

# THIS IS FOR ANALYZING JUST LOF_v04_analysis_df:
filtered_LOF_v04_analysis_df = LOF_v04_analysis_df[LOF_v04_analysis_df['num_total_events_used_for_test'] > 0]
filtered_LOF_v04_analysis_df['num_patients'] = list(map(lambda x: len(set(SV_df[(SV_df['gene1'] == x) | (SV_df['gene2'] == x)]['individual'])), list(filtered_LOF_v04_analysis_df['gene'])))
filtered_LOF_v04_analysis_df['num_events'] = list(map(lambda x: SV_df[(SV_df['gene1'] == x) | (SV_df['gene2'] == x)].shape[0], list(filtered_LOF_v04_analysis_df['gene'])))
filtered_LOF_v04_analysis_df['num_breakpoints'] = list(map(lambda x: (list(SV_df['gene1']) + list(SV_df['gene2'])).count(x), list(filtered_LOF_v04_analysis_df['gene'])))
filtered_LOF_v04_analysis_df['RNA_underexp_p_value'] = list(map(lambda x: the_depleted_rna_df[the_depleted_rna_df['genes'] == x]['p-values'].iloc[0] if the_depleted_rna_df[the_depleted_rna_df['genes'] == x].shape[0] > 0 else "N/A", list(filtered_LOF_v04_analysis_df['gene'])))
temp_min_num_patients = 2
filtered_LOF_v04_analysis_df = filtered_LOF_v04_analysis_df[filtered_LOF_v04_analysis_df['num_patients'] >= temp_min_num_patients].copy()
filtered_LOF_v04_analysis_df['q_value_LOF'] = multitest.multipletests(list(filtered_LOF_v04_analysis_df['p_value_LOF']), method = "fdr_bh")[1]
filtered_LOF_v04_analysis_df = filtered_LOF_v04_analysis_df[['gene','num_patients','num_events','num_breakpoints','num_total_events_used_for_test','num_intragenic_events','num_intergenic_events','num_LOF_events','prob_of_LOF','p_value_LOF','q_value_LOF','RNA_underexp_p_value']]
# To view the first 25 genes sorted q-value from the above line:
filtered_LOF_v04_analysis_df.sort_values(by=['p_value_LOF']).head(25)