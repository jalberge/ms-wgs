import pandas as pd
import numpy as np
import dalmatian
import scipy.stats
from statsmodels.stats import multitest
from mat4py import loadmat
import sys

def flatten_list(l):
    return [item for sublist in l for item in sublist]

def completely_flatten_list(l):
    if isinstance(l, list):
        if len(l) == 0:
            return []
        elif len(l) == 1:
            return completely_flatten_list(l[0])
        else:
            return completely_flatten_list(l[0]) + completely_flatten_list(l[1:])
    else:
        return [l]

def produce_analysis_df():
    data = loadmat('hg38_R_with_hugo_symbols_with_DUX4L1_HMGN2P46_MALAT1.mat')
    chr_vals = np.array(data['R']['chr'])
    start_coords = np.array(data['R']['code_start']).astype(float)
    end_coords = np.array(data['R']['code_end']).astype(float)
    exon_start_coords = list(map(lambda x: completely_flatten_list(x), (data['R']['exon_starts'])))
    exon_end_coords = list(map(lambda x: completely_flatten_list(x), (data['R']['exon_ends'])))
    genes = list(np.array(data['R']['gene']).flatten())
    gene_orientations = list(np.array(data['R']['strand']).flatten())
    # As it turns out the same gene can occur multiple times in R.mat, but I am going with the assumption that the orientation for a given gene (and its transcripts) is always the same
    dict_of_genes_and_orientations = {}
    for g_i in range(0, len(genes)):
        dict_of_genes_and_orientations[genes[g_i]] = gene_orientations[g_i]

    # This is for producing the intervals of genes:
    chr_and_start_and_end_coords = np.concatenate((chr_vals, start_coords, end_coords), axis=1)
    d = {'chr': chr_and_start_and_end_coords[:,0], 'start': chr_and_start_and_end_coords[:,1], 'end': chr_and_start_and_end_coords[:,2]}
    chr_and_start_and_end_coords_df = pd.DataFrame(data=d)
    # Need to drop any columns with nan start/end coordinates:
    chr_and_start_and_end_coords_df = chr_and_start_and_end_coords_df[(chr_and_start_and_end_coords_df['start'] != 'nan') & (chr_and_start_and_end_coords_df['end'] != 'nan')]
    chr_and_start_and_end_coords_df['start'] = np.array(chr_and_start_and_end_coords_df.copy()['start']).astype(float).astype(int)
    chr_and_start_and_end_coords_df['end'] = np.array(chr_and_start_and_end_coords_df.copy()['end']).astype(float).astype(int)
    chr_and_start_and_end_coords_df.to_csv('genes_from_updated_R_mat_file_start_and_end_coords.tsv',header=False,sep='\t',index=False)

    # At this point I just ran the commands from my file "commands_i_ran_to_get_merged_intervals_for_genes_from_R_mat_file.txt"
    # Now I can work with the output of those commands below

    # This is for producing the intervals of exons:
    exon_chr_vals = []
    exon_start_coord_vals = []
    exon_end_coord_vals = []
    for i in range(0,len(chr_vals)):
        for j in range(0,len(exon_start_coords[i])):
            exon_chr_vals.append(chr_vals[i][0])
            exon_start_coord_vals.append(exon_start_coords[i][j])
            exon_end_coord_vals.append(exon_end_coords[i][j])
    d_exon = {'chr': exon_chr_vals, 'start': exon_start_coord_vals, 'end': exon_end_coord_vals}
    exon_chr_and_start_and_end_coords_df = pd.DataFrame(data=d_exon)
    exon_chr_and_start_and_end_coords_df.to_csv('exons_from_updated_R_mat_file_start_and_end_coords.tsv',header=False,sep='\t',index=False)

    # At this point I just ran the commands from my file "commands_i_ran_to_get_merged_intervals_for_exons_from_R_mat_file.txt"
    # Now I can work with the output of those commands below

    merged_gene_intervals_df = pd.read_csv('genes_from_updated_R_mat_file_start_and_end_coords_sorted_merged.tsv', sep='\t',names=["chr", "start", "end"])
    merged_gene_intervals_df['interval width'] = merged_gene_intervals_df['end'].subtract(merged_gene_intervals_df['start'])
    span_that_gene_coding_regions_take_up = merged_gene_intervals_df['interval width'].sum()
    merged_exon_intervals_df = pd.read_csv('exons_from_updated_R_mat_file_start_and_end_coords_sorted_merged.tsv', sep='\t',names=["chr", "start", "end"])
    merged_exon_intervals_df['interval width'] = merged_exon_intervals_df['end'].subtract(merged_exon_intervals_df['start'])
    span_that_exonic_regions_take_up = merged_exon_intervals_df['interval width'].sum()
    # This is the total length of the genome for males (meaning Y is included) according to hg38:
    length_of_genome_male = 3088269832
    # This is the total length of the genome for females (meaning Y is excluded) according to hg38:
    length_of_genome_female = 3031042417
    # This is the average length of the genome (if approximately 50% of the population is male vs. female)
    length_of_genome = int(np.round(length_of_genome_male * 0.5 + length_of_genome_female * 0.5))
    proportion_of_genome_thats_intronic_or_exonic_interval = span_that_gene_coding_regions_take_up / length_of_genome
    proportion_of_genome_thats_exonic_interval = span_that_exonic_regions_take_up / length_of_genome
    proportion_of_genome_thats_intronic_interval = proportion_of_genome_thats_intronic_or_exonic_interval - proportion_of_genome_thats_exonic_interval





    all_SV_pairs_df = pd.read_csv('./All_Pairs.dRanger_etc.filtered_SV.tsv', sep='\t')
    # Taking out the 16 pairs that have low purity:
    wm = dalmatian.WorkspaceManager("broad-firecloud-gdac/CTSP_DLBCL1_ControlledAccess_hg38_v1-0_DATA")
    pair_sets_df = wm.get_pair_sets()
    pairs_df = wm.get_pairs()
    pairs_df_for_low_purity_pairs = pairs_df.loc[pair_sets_df.loc['FROZEN_for_high_coverage_BAMs_low_purity_pairs'].pairs]
    list_of_low_purity_pairs = list(pairs_df_for_low_purity_pairs.index)
    all_SV_pairs_df = all_SV_pairs_df[~all_SV_pairs_df['individual'].isin(list_of_low_purity_pairs)]

    # Finding for each gene how many breakpoints were annotated:
    dict_of_number_of_breakpoints_annotated_for_each_gene = {}
    list_of_all_breakpoint_gene_annotations = list(all_SV_pairs_df['gene1']) + list(all_SV_pairs_df['gene2'])
    for unique_gene in list(set(list_of_all_breakpoint_gene_annotations)):
        dict_of_number_of_breakpoints_annotated_for_each_gene[unique_gene] = list_of_all_breakpoint_gene_annotations.count(unique_gene)
    dict_of_number_of_breakpoints_annotated_for_each_gene_sorted = dict(sorted(dict_of_number_of_breakpoints_annotated_for_each_gene.items(), key=lambda item: item[1],reverse=True))
    print('dict_of_number_of_breakpoints_annotated_for_each_gene_sorted:')
    print(dict_of_number_of_breakpoints_annotated_for_each_gene_sorted)





    # which_method_we_are_using = 1
    which_method_we_are_using = 2
    if which_method_we_are_using == 1:
        ##### METHOD 1: Doing statistical tests for loss-of-function for every SV associated with a gene #####
        p_value_threshold = 2*proportion_of_genome_thats_intronic_or_exonic_interval*(1-proportion_of_genome_thats_intronic_or_exonic_interval) + (5/6)*proportion_of_genome_thats_intronic_or_exonic_interval**2
        counts_of_gene_breakpoints_with_LOF = {}
        for unique_gene in list(set(list(all_SV_pairs_df['gene1']) + list(all_SV_pairs_df['gene2']))):
            counts_of_gene_breakpoints_with_LOF[unique_gene] = 0
        # Finding which SVs have loss-of-function according to my criteria:
        for index, row in all_SV_pairs_df.iterrows():
            pass # Need to fill this out later
    elif which_method_we_are_using == 2:
        ##### METHOD 2: Doing statistical tests for loss-of-function for every breakpoint associated with a gene #####
        # # Old p_value_threshold:
        # p_value_threshold = proportion_of_genome_thats_intronic_or_exonic_interval * ((1-proportion_of_genome_thats_intronic_or_exonic_interval) + (5/6)*proportion_of_genome_thats_intronic_or_exonic_interval)
        # New p_value_threshold:
        p_value_threshold = proportion_of_genome_thats_exonic_interval * (1 - (1/6)*proportion_of_genome_thats_exonic_interval) + \
                            proportion_of_genome_thats_intronic_interval * (1 - (1/6)*proportion_of_genome_thats_intronic_interval) # - (1/6)*proportion_of_genome_thats_exonic_interval)
        counts_of_gene_breakpoints_with_LOF = {}
        for unique_gene in list(set(list(all_SV_pairs_df['gene1']) + list(all_SV_pairs_df['gene2']))):
            counts_of_gene_breakpoints_with_LOF[unique_gene] = 0
        # Finding which breakpoints have loss-of-function according to my criteria:
        for index, row in all_SV_pairs_df.iterrows():
            gene1 = row['gene1']
            gene2 = row['gene2']
            for which_breakpoint in ["bp1","bp2"]:
                if which_breakpoint == "bp1":
                    condition_bp1_intron_to_non_intron = (row['site1'].startswith("Intron")) and (row['site2'].startswith("Exon") or row['site2'].startswith("5'-UTR") or row['site2'].startswith("3'-UTR") or row['site2'].startswith("Promoter") or row['site2'].startswith("IGR"))
                    condition_bp1_exon_to_non_exon = (row['site1'].startswith("Exon")) and (row['site2'].startswith("Intron") or row['site2'].startswith("5'-UTR") or row['site2'].startswith("3'-UTR") or row['site2'].startswith("Promoter") or row['site2'].startswith("IGR"))
                    condition_bp1_intron_to_intron_not_in_frame = False
                    if (row['site1'].startswith("Intron") and row['site2'].startswith("Intron")):
                        # if (dict_of_genes_and_orientations[gene1] != dict_of_genes_and_orientations[gene2] and row['str1'] != row['str2']) or \
                        #     (dict_of_genes_and_orientations[gene1] == dict_of_genes_and_orientations[gene2] and row['str1'] == row['str2']):
                        #     condition_bp1_intron_to_intron_not_in_frame = True
                        # elif ______________:
                        #     condition_bp1_intron_to_intron_not_in_frame = True
                        
                        # This is hacky and I may need to develop the commented out code above further at some point, but it is what I will do for now since I don't have the dRanger annotator implemented in Python:
                        if (not "in frame" in row['fusion']) and (not "within intron" in row['fusion']):
                            condition_bp1_intron_to_intron_not_in_frame = True
                    condition_bp1_exon_to_exon_not_in_frame = False
                    if (row['site1'].startswith("Exon") and row['site2'].startswith("Exon")):
                        raise("ERROR: For our data for DLBCL this should never actually happen — I looked through all events and there were no exon-exon fusions")
                        #### NEED TO ACTUALLY IMPLEMENT THIS LATER! I JUST DON'T HAVE TO WORRY ABOUT IT FOR CTSP DLBCL BECAUSE THERE ARE NO EXON-EXON FUSIONS SO THIS IS CURRENTLY A HACK.
                        #### MAY INVOLVE WORK WHERE I HAVE TO INTEGRATE THE DRANGER ANNOTATOR ALGORITHM HERE. OR MAYBE I CAN PORT IT INTO PYTHON AND PORT IT INTO THIS SCRIPT.
                    entire_condition_for_breakpoint_having_LOF = condition_bp1_intron_to_non_intron or condition_bp1_exon_to_non_exon or condition_bp1_intron_to_intron_not_in_frame or condition_bp1_exon_to_exon_not_in_frame
                    if entire_condition_for_breakpoint_having_LOF:
                        counts_of_gene_breakpoints_with_LOF[row['gene1']] += 1
                elif which_breakpoint == "bp2":
                    condition_bp2_intron_to_non_intron = (row['site2'].startswith("Intron")) and (row['site1'].startswith("Exon") or row['site1'].startswith("5'-UTR") or row['site1'].startswith("3'-UTR") or row['site1'].startswith("Promoter") or row['site1'].startswith("IGR"))
                    condition_bp2_exon_to_non_exon = (row['site2'].startswith("Exon")) and (row['site1'].startswith("Intron") or row['site1'].startswith("5'-UTR") or row['site1'].startswith("3'-UTR") or row['site1'].startswith("Promoter") or row['site1'].startswith("IGR"))
                    condition_bp2_intron_to_intron_not_in_frame = False
                    if (row['site1'].startswith("Intron") and row['site2'].startswith("Intron")):
                        # if (dict_of_genes_and_orientations[gene1] != dict_of_genes_and_orientations[gene2] and row['str1'] != row['str2']) or \
                        #     (dict_of_genes_and_orientations[gene1] == dict_of_genes_and_orientations[gene2] and row['str1'] == row['str2']):
                        #     condition_bp1_intron_to_intron_not_in_frame = True
                        # elif ______________:
                        #     condition_bp1_intron_to_intron_not_in_frame = True
                        
                        # This is hacky and I may need to develop the commented out code above further at some point, but it is what I will do for now since I don't have the dRanger annotator implemented in Python:
                        if (not "in frame" in row['fusion']) and (not "within intron" in row['fusion']):
                            condition_bp2_intron_to_intron_not_in_frame = True
                    condition_bp2_exon_to_exon_not_in_frame = False
                    if (row['site1'].startswith("Exon") and row['site2'].startswith("Exon")):
                        raise("ERROR: For our data for DLBCL this should never actually happen — I looked through all events and there were no exon-exon fusions")
                        #### NEED TO ACTUALLY IMPLEMENT THIS LATER! I JUST DON'T HAVE TO WORRY ABOUT IT FOR CTSP DLBCL BECAUSE THERE ARE NO EXON-EXON FUSIONS SO THIS IS CURRENTLY A HACK.
                        #### MAY INVOLVE WORK WHERE I HAVE TO INTEGRATE THE DRANGER ANNOTATOR ALGORITHM HERE. OR MAYBE I CAN PORT IT INTO PYTHON AND PORT IT INTO THIS SCRIPT.
                    entire_condition_for_breakpoint_having_LOF = condition_bp2_intron_to_non_intron or condition_bp2_exon_to_non_exon or condition_bp2_intron_to_intron_not_in_frame or condition_bp2_exon_to_exon_not_in_frame
                    if entire_condition_for_breakpoint_having_LOF:
                        counts_of_gene_breakpoints_with_LOF[row['gene2']] += 1
    else:
        raise("Invalid method specified")


    gene_names = list_of_all_breakpoint_gene_annotations.copy()
    unique_genes = list(set(gene_names.copy()))
    gene_counts = []
    LOF_counts_for_each_gene = []
    for unique_gene in unique_genes:
        gene_counts.append(gene_names.count(unique_gene))
        LOF_counts_for_each_gene.append(counts_of_gene_breakpoints_with_LOF[unique_gene])

    analysis_data = {'Gene': unique_genes, 'Number of SV breakpoints': gene_counts, 'Number of breakpoints with LOF by my criteria': LOF_counts_for_each_gene, 'Prop. of breakpoints with LOF by my criteria': list(np.array(LOF_counts_for_each_gene) / np.array(gene_counts))}
    analysis_df = pd.DataFrame(data=analysis_data)
    analysis_df['p-value of given number of breakpoints or more having LOF'] = list(map(lambda x: scipy.stats.binom_test(x[0], n=x[1], p=p_value_threshold, alternative='greater'), zip(list(analysis_df['Number of breakpoints with LOF by my criteria']),list(analysis_df['Number of SV breakpoints']))))
    analysis_df['q-value via B-H of given number of breakpoints or more having LOF'] = list(multitest.multipletests(list(analysis_df['p-value of given number of breakpoints or more having LOF']), method = "fdr_bh")[1])
    analysis_df['q-value via B-Y of given number of breakpoints or more having LOF'] = list(multitest.multipletests(list(analysis_df['p-value of given number of breakpoints or more having LOF']), method = "fdr_by")[1])

    analysis_df['Number of SVs'] = list(map(lambda gene: all_SV_pairs_df[(all_SV_pairs_df['gene1'] == gene) | ((all_SV_pairs_df['gene2'] == gene))].shape[0], list(analysis_df['Gene'])))
    analysis_df['Number of Patients with SV breakpoint annotated with gene'] = list(map(lambda gene: len(set(list(all_SV_pairs_df[(all_SV_pairs_df['gene1'] == gene) | ((all_SV_pairs_df['gene2'] == gene))]['individual']))), list(analysis_df['Gene'])))

    analysis_df = analysis_df[["Gene","Number of Patients with SV breakpoint annotated with gene","Number of SVs","Number of SV breakpoints","Number of breakpoints with LOF by my criteria","Prop. of breakpoints with LOF by my criteria","p-value of given number of breakpoints or more having LOF","q-value via B-H of given number of breakpoints or more having LOF","q-value via B-Y of given number of breakpoints or more having LOF"]]
    analysis_df.sort_values(by=['q-value via B-H of given number of breakpoints or more having LOF'],inplace=True,ascending=True)

    return analysis_df


