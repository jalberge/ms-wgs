import numpy as np
import pandas as pd
from statsmodels.stats import multitest
import matplotlib.pyplot as plt
from matplotlib import patches

# # Shortcuts for testing:
# cohort = "JB_MM_SU2C"
# results = "LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_1000000bp_v10.tsv"
# SV_list = "../datasets/JB_MM_SU2C/20230509_MMRF_SU2C_MARK_OW_SV_filtered_results_baseline_hg38_sd_gt_0.annotated.tsv"
# SV_sublists_dir = "../SV_list_subsets_of_regions_within_distance_of_gene/v10/JB_MM_SU2C/annotations_relative_to_given_gene_and_boundary_threshold_with_indication_of_LOF_or_not"
# sw = 1000000
# min_patient_thresh = 8

# surrounding_window = sw
# min_num_patients_for_FDR = min_patient_thresh
# name_of_plot_path = 'plots/' + cohort + '_SV_CoMut_like_plot_LOF_v10_model_thresh_of_proximity_' + str(surrounding_window) + '_min_' + str(min_num_patients_for_FDR) + '_patients.png'


### THIS PART OF THE CODE IS WHERE WE PRODUCE THE DATAFRAME FOR THE SV COMUT-LIKE PLOT:
def produce_comut_like_plot_dataframe(cohort, results, SV_list, SV_sublists_dir, sw, min_patient_thresh):
    # Obtain results of SV LoF significance model:
    original_results_df = pd.read_csv("../LOF_model_results/" + cohort + "/" + results,sep='\t')
    # Obtain the original SV list re-annoted with the annotator that prioritizes driver transcripts:
    SV_list_df = pd.read_csv(SV_list,sep='\t')
    # Filter and perform multiple test correction on the SV LoF significance model results as appropriate, using min_patient_thresh for filtration beforehand:
    results_df = original_results_df[original_results_df['num_total_events_used_for_test'] > 0]
    results_df = results_df[results_df['num_patients_used_for_test'] >= min_patient_thresh].copy()
    results_df['q_value_LOF'] = multitest.multipletests(list(results_df['p_value_LOF']), method = "fdr_bh")[1]
    results_df = results_df[results_df['q_value_LOF'] <= 0.25].sort_values(by=['p_value_LOF'])
    # Set up dataframe for CoMut plot with empty values but appropriate row and column names:
    dataframe_for_plot = pd.concat([pd.Series(map(lambda x: "", list(range(len(results_df['gene'])))))] * len(set(SV_list_df['individual'])),axis=1)
    dataframe_for_plot.set_index(pd.Index(list(results_df['gene'])),inplace=True)
    # dataframe_for_plot.set_index(pd.Index(list(results_df['gene'])[::-1]),inplace=True)
    dataframe_for_plot.columns = list(set(SV_list_df['individual']))
    # Fill in dataframe for CoMut plot as appropriate based off whether there is at least one SV for that patient and gene as well as whether or not at least one is LoF:
    for g in list(results_df['gene']):
        SV_sublist_for_gene_df = pd.read_csv(SV_sublists_dir + "/SV_list_filtered_" + g + "_within_" + str(sw) + "bp.reannotated_with_LOF_indication.tsv",sep='\t')
        individuals_with_at_least_one_LoF_event_for_gene = list(set(SV_sublist_for_gene_df[SV_sublist_for_gene_df['LOF_or_not'] == 1]['individual']))
        individuals_with_no_LoF_event_for_gene = list(set(SV_sublist_for_gene_df['individual']) - set(individuals_with_at_least_one_LoF_event_for_gene))
        dataframe_for_plot.loc[g, individuals_with_at_least_one_LoF_event_for_gene] = "At least one SV present; at least one LoF"
        dataframe_for_plot.loc[g, individuals_with_no_LoF_event_for_gene] = "At least one SV present; no LoF"
    # Order the patients (x-axis) as appropriate:
    reordered_individuals = []
    not_yet_reordered_individuals = set(dataframe_for_plot.columns)
    for gene_index in range(len(results_df)):
        print('gene_index:',gene_index)
        for rev_index in range(len(results_df),gene_index,-1):
            individuals_to_append = list(filter(lambda i: (dataframe_for_plot.iloc[gene_index:rev_index][i] != "").all(), not_yet_reordered_individuals))
            if not individuals_to_append:
                continue
            else:
                individuals_to_append_reordered = []
                for x in range(gene_index,rev_index):
                    for indiv in individuals_to_append:
                        if (dataframe_for_plot.iloc[x][indiv] == "At least one SV present; no LoF") and (not indiv in individuals_to_append_reordered):
                            individuals_to_append_reordered = [indiv] + individuals_to_append_reordered
                individuals_to_append_reordered = list(set(individuals_to_append) - set(individuals_to_append_reordered)) + individuals_to_append_reordered
                reordered_individuals += individuals_to_append_reordered
                not_yet_reordered_individuals -= set(individuals_to_append_reordered)
    dataframe_for_plot = dataframe_for_plot[reordered_individuals + list(not_yet_reordered_individuals)]
    dataframe_for_plot = dataframe_for_plot.loc[list(dataframe_for_plot.index)[::-1]]
    return dataframe_for_plot


### THIS PART OF THE CODE IS WHERE WE PRODUCE THE ACTUAL PLOT:
def produce_comut_like_plot_plotting(dataframe_for_plot,name_of_plot_path):
    figsize = (20,6)
    x_padding = 0.08
    y_padding = 0.08
    width = 1-2*x_padding
    height = 1-2*y_padding
    fig = plt.figure(figsize=figsize)
    ax = fig.add_subplot()
    for g in range(len(dataframe_for_plot.index)):
        gene = dataframe_for_plot.index[g]
        print("gene:", gene)
        for i in range(len(dataframe_for_plot.columns)):
            x_base = i + x_padding
            y_base = g + y_padding
            indiv = dataframe_for_plot.columns[i]
            if dataframe_for_plot.loc[gene,indiv] == "At least one SV present; at least one LoF":
                patch_options = {'facecolor': (0.749, 0.047, 0.047)}
            elif dataframe_for_plot.loc[gene,indiv] == "At least one SV present; no LoF":
                patch_options = {'facecolor': (0.031, 0.549, 0.388)}
            else:
                patch_options = {'facecolor': (1, 1, 1)}
            rect = patches.Rectangle((x_base,y_base),width,height,**patch_options)
            ax.add_patch(rect)
    ax.set_ylim([0, len(dataframe_for_plot.index) + y_padding])
    ax.set_xlim([0, len(dataframe_for_plot.columns) + x_padding])
    ax.set_yticks(np.arange(0.5, len(dataframe_for_plot.index) + 0.5))
    ax.set_yticklabels(dataframe_for_plot.index, style='italic',size=5)
    ax.get_xaxis().set_visible(False)
    ax.tick_params(axis='both',which='both',bottom=False,top=False,length=0)
    for loc in ['top', 'right', 'bottom', 'left']:
        ax.spines[loc].set_visible(False)
    plt.savefig(name_of_plot_path)


if __name__ == '__main__':
    ####################### PARAMETERS TO SPECIFY #######################
    cohort = "JB_MM_SU2C"
    signifcance_test_results_file_name = "../model_results/" + cohort + "/LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_1000000bp_v10.tsv"
    input_SV_list = "../datasets/JB_MM_SU2C/20230509_MMRF_SU2C_MARK_OW_SV_filtered_results_baseline_hg38_sd_gt_0.annotated.tsv"
    directory_for_SV_sublists_per_gene = "../SV_list_subsets_of_regions_within_distance_of_gene/v10/JB_MM_SU2C/annotations_relative_to_given_gene_and_boundary_threshold_with_indication_of_LOF_or_not"
    surrounding_window = 1000000
    min_num_patients_for_FDR = 8
    ################### END OF PARAMETERS TO SPECIFY ####################
    dataframe_for_plotting = produce_comut_like_plot_dataframe(cohort,signifcance_test_results_file_name,input_SV_list,directory_for_SV_sublists_per_gene,surrounding_window,min_num_patients_for_FDR)
    dataframe_for_plotting.to_csv('../visualizations_and_associated_data/CoMut_like_SV_plots_for_driver_hits/dataframes_for_plotting/' + cohort + '_SV_CoMut_like_plot_input_data_LOF_v10_model_thresh_of_proximity_' + str(surrounding_window) + '_min_' + str(min_num_patients_for_FDR) + '_patients.tsv',sep='\t')
    produce_comut_like_plot_plotting(dataframe_for_plotting,'../visualizations_and_associated_data/CoMut_like_SV_plots_for_driver_hits/plots/' + cohort + '_SV_CoMut_like_plot_LOF_v10_model_thresh_of_proximity_' + str(surrounding_window) + '_min_' + str(min_num_patients_for_FDR) + '_patients.png')
