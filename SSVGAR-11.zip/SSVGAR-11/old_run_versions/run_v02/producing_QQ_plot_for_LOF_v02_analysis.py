
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from statsmodels.stats import multitest
from adjustText import adjust_text
import scipy.stats
from statsmodels.stats import multitest
from qtl import annotation
from find_p_and_q_values_of_rna_seq_expression_from_wilcoxon_rank_sum_test import produce_p_values_for_genes_enriched_and_depleted
from capy import num as num

# This is me modifying Julian's version of his QQ plots function for my analysis:
def custom_QQ(pvalues, labels = None, sig_thresh = 0.1, near_sig_thresh = 0.25, fnum = None):
    si = np.argsort(-np.log10(pvalues))
    logp = -np.log10(pvalues)[si]
    n_p = len(logp)

    # expected quantiles
    x = -np.log10(np.r_[n_p:0:-1]/(n_p + 1))

    #
    # FDR
    _, q, _, _ = multitest.multipletests(pvalues[si], method = "fdr_bh")
    sig_idx = q < sig_thresh
    n_sig_idx = q < near_sig_thresh

    print(sig_idx)
    print(n_sig_idx)
    print('How many are sig:', list(sig_idx).count(True))
    print('How many are near_sig but not sig:', list(n_sig_idx).count(True)-list(sig_idx).count(True))

    fdr_color_idx = np.c_[sig_idx, n_sig_idx]@np.r_[2, 1]

    #                      nonsig     near sig   <padding>     sig
    fdr_colors = np.array([[0, 0, 1], [0, 1, 1], [-1, -1, -1], [1, 0, 0]])

    #
    # plot
    f = plt.figure(fnum); plt.clf()
    plt.scatter(x, logp, c = fdr_colors[fdr_color_idx])

    # 1:1 line
    plt.plot(plt.xlim(), plt.xlim(), color = 'k', linestyle = ':')
    
    # # Modification I made -Xavi. Comment out if you want to properly produce QQ_plot_p_values.png, not QQ_plot_p_values_cutoff_observed_quantile_at_1e-10.png
    # orig_bottom,orig_top = plt.ylim()
    # plt.ylim(orig_bottom,2)

    #
    # labels (if given)
    if labels is not None:
        if len(labels) != len(x):
            raise ValueError("Length of labels must match length of p-value array")
        labels = labels[si]
        label_plt = [plt.text(x, y, l) for x, y, l in zip(x[n_sig_idx], logp[n_sig_idx], labels[n_sig_idx])]
        adjust_text(label_plt, arrowprops = { 'color' : 'k', "arrowstyle" : "-" })

    plt.xlabel("Expected quantile (-log10)")
    plt.ylabel("Observed quantile (-log10)")

    return f


LOF_v02_analysis_df = pd.read_csv('LOF_model_results_for_all_genes_that_have_SVs_across_at_least_two_patients_threshold_of_proximity_500000bp_v02.tsv',sep='\t') # This was produced by literally just running "python SV_analysis_loss_of_function_events_v02.py"
annot_v36 = annotation.Annotation("gencode.v36.annotation.gtf")
the_enriched_rna_df, the_depleted_rna_df = produce_p_values_for_genes_enriched_and_depleted(annot_v36, "All_Pairs.dRanger_etc.filtered_SV.columns_subset_enhanced_genes_100000bp_with_annotations.tsv")
merged_df = the_depleted_rna_df.merge(LOF_v02_analysis_df,left_on='genes',right_on='gene').drop(columns=['gene','q-values']).rename(columns={"num_total_events_used_for_test": "num_total_events_used_for_LOF_test", "p-values": "p_value_RNA_underexp"})
cols_for_merged_df = list(merged_df.columns)
cols_for_merged_df.remove('p_value_RNA_underexp')
merged_df = merged_df[cols_for_merged_df + ['p_value_RNA_underexp']]

min_num_patients = 5
merged_df_final = merged_df[merged_df["Number of patients"] >= min_num_patients].copy()
merged_df_final['combined_p_value'] = list(map(lambda x: scipy.stats.combine_pvalues([x[0],x[1]],method='fisher')[1], zip(list(merged_df_final['p_value_RNA_underexp']), list(merged_df_final['p_value_LOF']))))


fig_to_save = custom_QQ(np.array(list(merged_df_final['combined_p_value'])))
# This is for producing the default QQ plots:
fig_to_save.savefig('images/' + 'QQ_plot_LOF_v02_model_combined_pvalues_of_LOF_and_RNA_depletion_min_' + str(min_num_patients) + '_patients.png')


# fig_to_save.savefig('images/' + 'QQ_plot_LOF_v02_model_combined_pvalues_of_LOF_and_RNA_depletion_min_' + str(min_num_patients) + '_patients_cutoff_observed_quantile_at_1e-2.png')



